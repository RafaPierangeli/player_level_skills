package com.player_level_skills.level;

import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_6880;

public class SkillAttribute {

    private final int id;
    private final class_6880<class_1320> attibute;
    private final float baseValue;
    private final float levelValue;
    private final class_1322.class_1323 operation;

    public SkillAttribute(int id, class_6880<class_1320> attibute, float baseValue, float levelValue, class_1322.class_1323 operation) {
        this.id = id;
        this.attibute = attibute;
        this.baseValue = baseValue;
        this.levelValue = levelValue;
        this.operation = operation;
    }

    public int getId() {
        return id;
    }

    public class_6880<class_1320> getAttibute() {
        return attibute;
    }

    public float getBaseValue() {
        return baseValue;
    }

    public float getLevelValue() {
        return levelValue;
    }

    public class_1322.class_1323 getOperation() {
        return operation;
    }

}

