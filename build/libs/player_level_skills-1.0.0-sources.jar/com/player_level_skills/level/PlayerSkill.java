package com.player_level_skills.level;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2487;

public class PlayerSkill {

    private final int id;
    private int level;

    public PlayerSkill(int id, int level) {
        this.id = id;
        this.level = Math.max(0, level);
    }

    public PlayerSkill(class_2487 nbt) {
        this.id = nbt.method_10550("Id").orElse(0);
        this.level = nbt.method_10550("Level").orElse(0);

        if (this.level < 0) {
            this.level = 0;
        }
    }

    public static PlayerSkill readDataFromView(class_11368 skillView) {
        if (skillView == null) {
            return null;
        }

        int id = skillView.method_71424("Id", 0);
        int level = skillView.method_71424("Level", 0);

        return new PlayerSkill(id, Math.max(0, level));
    }

    public void writeDataToNbt(class_11372 skillView) {
        skillView.method_71465("Id", this.id);
        skillView.method_71465("Level", this.level);
    }

    public int getId() {
        return id;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = Math.max(0, level);
    }

    public void increaseLevel(int level) {
        Skill skill = LevelManager.SKILLS.get(this.id);
        if (skill == null) {
            this.level = Math.max(0, this.level + level);
            return;
        }

        int maxLevel = skill.getMaxLevel();
        if ((this.level + level) <= maxLevel) {
            this.level += level;
        } else {
            this.level = maxLevel;
        }

        if (this.level < 0) {
            this.level = 0;
        }
    }

    public void decreaseLevel(int level) {
        if ((this.level - level) >= 0) {
            this.level -= level;
        } else {
            this.level = 0;
        }
    }
}