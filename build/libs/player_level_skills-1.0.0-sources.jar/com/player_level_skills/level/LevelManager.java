package com.player_level_skills.level;

import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.level.restriction.PlayerRestriction;
import com.player_level_skills.util.LevelHelper;
import com.player_level_skills.util.PacketHelper;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_2248;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class LevelManager {


    public static final Map<Integer, Skill> SKILLS = new HashMap<>();
    public static final Map<Integer, PlayerRestriction> BLOCK_RESTRICTIONS = new HashMap<>();
    public static final Map<Integer, PlayerRestriction> CRAFTING_RESTRICTIONS = new HashMap<>();
    public static final Map<Integer, PlayerRestriction> ENTITY_RESTRICTIONS = new HashMap<>();
    public static final Map<Integer, PlayerRestriction> ITEM_RESTRICTIONS = new HashMap<>();
    public static final Map<Integer, PlayerRestriction> MINING_RESTRICTIONS = new HashMap<>();
    public static final Map<Integer, PlayerRestriction> ENCHANTMENT_RESTRICTIONS = new HashMap<>();
    public static final Map<String, SkillBonus> BONUSES = new HashMap<>();

    private final class_1657 playerEntity;
    private Map<Integer, PlayerSkill> playerSkills = new HashMap<>();

    // Level
    private int overallLevel;
    private int totalLevelExperience;
    private float levelProgress;
    private int skillPoints;

    public LevelManager(class_1657 playerEntity) {
        this.playerEntity = playerEntity;

        for (Skill skill : SKILLS.values()) {
            if (!this.playerSkills.containsKey(skill.getId())) {
                this.playerSkills.put(skill.getId(), new PlayerSkill(skill.getId(), 0));
            } else if (this.playerSkills.get(skill.getId()).getLevel() > skill.getMaxLevel()) {
                this.playerSkills.get(skill.getId()).setLevel(skill.getMaxLevel());
            }
        }
    }

    public class_1657 getPlayerEntity() {
        return playerEntity;
    }

    public void readNbt(class_11368 view) {
        this.overallLevel = view.method_71424("Level", 1);
        this.levelProgress = view.method_71423("LevelProgress", 0.0f);
        this.totalLevelExperience = view.method_71424("TotalLevelExperience", 0);
        this.skillPoints = view.method_71424("SkillPoints", 0);

        class_11368 skillsView = view.method_71434("Skills");
        if (skillsView != null) {
            for (String key : skillsView.keys()) {
                class_11368 skillView = skillsView.method_71434(key);
                if (skillView == null) {
                    continue;
                }

                PlayerSkill skill = PlayerSkill.readDataFromView(skillView);
                if (SKILLS.containsKey(skill.getId())) {
                    playerSkills.put(skill.getId(), skill);
                }
            }
        }
    }

    public void writeNbt(class_11372 view) {
        view.method_71465("Level", this.overallLevel);
        view.method_71464("LevelProgress", this.levelProgress);
        view.method_71465("TotalLevelExperience", this.totalLevelExperience);
        view.method_71465("SkillPoints", this.skillPoints);

        class_11372 skillsView = view.method_71461("Skills");
        for (Map.Entry<Integer, PlayerSkill> entry : playerSkills.entrySet()) {
            class_11372 skillView = skillsView.method_71461("Skill" + entry.getKey());
            entry.getValue().writeDataToNbt(skillView);
        }
    }


    public Map<Integer, PlayerSkill> getPlayerSkills() {
        return playerSkills;
    }

    public void setPlayerSkills(Map<Integer, PlayerSkill> playerSkills) {
        this.playerSkills = playerSkills;
    }

    public void setOverallLevel(int overallLevel) {
        this.overallLevel = overallLevel;
    }

    public int getOverallLevel() {
        return overallLevel;
    }

    public void setTotalLevelExperience(int totalLevelExperience) {
        this.totalLevelExperience = totalLevelExperience;
    }

    public int getTotalLevelExperience() {
        return totalLevelExperience;
    }

    public void setSkillPoints(int skillPoints) {
        this.skillPoints = skillPoints;
    }

    public int getSkillPoints() {
        return skillPoints;
    }

    public void setLevelProgress(float levelProgress) {
        this.levelProgress = levelProgress;
    }

    public float getLevelProgress() {
        return levelProgress;
    }

    public void setSkillLevel(int skillId, int level) {
        this.playerSkills.get(skillId).setLevel(level);
    }

    public int getSkillLevel(int skillId) {
        // Maybe add a containsKey check here
        return this.playerSkills.get(skillId).getLevel();
    }

    public void addExperienceLevels(int levels) {
        this.overallLevel += levels;
        this.skillPoints += ConfigInit.CONFIG.pointsPerLevel;
        if (this.overallLevel < 0) {
            this.overallLevel = 0;
            this.levelProgress = 0.0F;
            this.totalLevelExperience = 0;
        }
    }

    public boolean isMaxLevel() {
        if (ConfigInit.CONFIG.overallMaxLevel > 0) {
            return this.overallLevel >= ConfigInit.CONFIG.overallMaxLevel;
        } else {
            int maxLevel = 0;
            for (Skill skill : SKILLS.values()) {
                maxLevel += skill.getMaxLevel();
            }
            return this.overallLevel >= maxLevel;
        }
    }

    public boolean hasAvailableLevel() {
        return this.skillPoints > 0;
    }
    // Recommend to use https://www.geogebra.org/graphing
    public int getNextLevelExperience() {
        if (isMaxLevel()) {
            return 0;
        }
        int experienceCost = (int) (ConfigInit.CONFIG.xpBaseCost + ConfigInit.CONFIG.xpCostMultiplicator * Math.pow(this.overallLevel, ConfigInit.CONFIG.xpExponent));
        if (ConfigInit.CONFIG.xpMaxCost != 0) {
            return experienceCost >= ConfigInit.CONFIG.xpMaxCost ? ConfigInit.CONFIG.xpMaxCost : experienceCost;
        } else {
            return experienceCost;
        }
    }
    // block
    public boolean hasRequiredBlockLevel(class_2248 block) {
        int itemId = class_7923.field_41175.method_10206(block);
        if (BLOCK_RESTRICTIONS.containsKey(itemId)) {
            PlayerRestriction playerRestriction = BLOCK_RESTRICTIONS.get(itemId);
            for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
                if (this.getSkillLevel(entry.getKey()) < entry.getValue()) {
                    return false;
                }
            }
        }
        return true;
    }

    public Map<Integer, Integer> getRequiredBlockLevel(class_2248 block) {
        int itemId = class_7923.field_41175.method_10206(block);
        if (BLOCK_RESTRICTIONS.containsKey(itemId)) {
            PlayerRestriction playerRestriction = BLOCK_RESTRICTIONS.get(itemId);
            return playerRestriction.getSkillLevelRestrictions();
        }
        return Map.of(0, 0);
    }
    // crafting
    public boolean hasRequiredCraftingLevel(class_1792 item) {
        int itemId = class_7923.field_41178.method_10206(item);
        if (CRAFTING_RESTRICTIONS.containsKey(itemId)) {
            PlayerRestriction playerRestriction = CRAFTING_RESTRICTIONS.get(itemId);
            for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
                if (this.getSkillLevel(entry.getKey()) < entry.getValue()) {
                    return false;
                }
            }
        }
        return true;
    }

    public Map<Integer, Integer> getRequiredCraftingLevel(class_1792 item) {
        int itemId = class_7923.field_41178.method_10206(item);
        if (CRAFTING_RESTRICTIONS.containsKey(itemId)) {
            PlayerRestriction playerRestriction = CRAFTING_RESTRICTIONS.get(itemId);
            return playerRestriction.getSkillLevelRestrictions();
        }
        return Map.of(0, 0);
    }

    // entity
    public boolean hasRequiredEntityLevel(class_1299<?> entityType) {
        int entityId = class_7923.field_41177.method_10206(entityType);
        if (ENTITY_RESTRICTIONS.containsKey(entityId)) {
            PlayerRestriction playerRestriction = ENTITY_RESTRICTIONS.get(entityId);
            for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
                if (this.getSkillLevel(entry.getKey()) < entry.getValue()) {
                    return false;
                }
            }
        }
        return true;
    }

    public Map<Integer, Integer> getRequiredEntityLevel(class_1299<?> entityType) {
        int entityId = class_7923.field_41177.method_10206(entityType);
        if (ENTITY_RESTRICTIONS.containsKey(entityId)) {
            PlayerRestriction playerRestriction = ENTITY_RESTRICTIONS.get(entityId);
            return playerRestriction.getSkillLevelRestrictions();
        }
        return Map.of(0, 0);
    }

    // item
    public boolean hasRequiredItemLevel(class_1792 item) {
        int itemId = class_7923.field_41178.method_10206(item);
        if (ITEM_RESTRICTIONS.containsKey(itemId)) {
            PlayerRestriction playerRestriction = ITEM_RESTRICTIONS.get(itemId);
            for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
                if (this.getSkillLevel(entry.getKey()) < entry.getValue()) {
                    return false;
                }
            }
        }
        return true;
    }

    public Map<Integer, Integer> getRequiredItemLevel(class_1792 item) {
        int itemId = class_7923.field_41178.method_10206(item);
        if (ITEM_RESTRICTIONS.containsKey(itemId)) {
            PlayerRestriction playerRestriction = ITEM_RESTRICTIONS.get(itemId);
            return playerRestriction.getSkillLevelRestrictions();
        }
        return Map.of(0, 0);
    }

    // mining
    public boolean hasRequiredMiningLevel(class_2248 block) {
        int itemId = class_7923.field_41175.method_10206(block);
        if (MINING_RESTRICTIONS.containsKey(itemId)) {
            PlayerRestriction playerRestriction = MINING_RESTRICTIONS.get(itemId);
            for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
                if (this.getSkillLevel(entry.getKey()) < entry.getValue()) {
                    return false;
                }
            }
        }
        return true;
    }

    public Map<Integer, Integer> getRequiredMiningLevel(class_2248 block) {
        int itemId = class_7923.field_41175.method_10206(block);
        if (MINING_RESTRICTIONS.containsKey(itemId)) {
            PlayerRestriction playerRestriction = MINING_RESTRICTIONS.get(itemId);
            return playerRestriction.getSkillLevelRestrictions();
        }
        return Map.of(0, 0);
    }

    // enchantment
    public boolean hasRequiredEnchantmentLevel(class_6880<class_1887> enchantment, int level) {
     //   int enchantmentId = Enchantment.getName(EnchantmentRegistry.getId(enchantment, level);
    //    if (ENCHANTMENT_RESTRICTIONS.containsKey(enchantmentId)) {
    //        PlayerRestriction playerRestriction = ENCHANTMENT_RESTRICTIONS.get(enchantmentId);
    //        for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
    //            if (this.getSkillLevel(entry.getKey()) < entry.getValue()) {
    //                return false;
    //            }
    //        }
    //    }
        return true;
    }

    public Map<Integer, Integer> getRequiredEnchantmentLevel(class_6880<class_1887> enchantment, int level) {
    //    int enchantmentId = EnchantmentRegistry.getId(enchantment, level);
    //    if (ENCHANTMENT_RESTRICTIONS.containsKey(enchantmentId)) {
    //        PlayerRestriction playerRestriction = ENCHANTMENT_RESTRICTIONS.get(enchantmentId);
    //        return playerRestriction.getSkillLevelRestrictions();
    //    }
        return Map.of(0, 0);
    }

    public boolean resetSkill(int skillId) {
        int level = this.getSkillLevel(skillId);
        if (level > 0) {
            this.setSkillPoints(this.getSkillPoints() + level);
            this.setSkillLevel(skillId, 0);
            PacketHelper.updatePlayerSkills((class_3222) this.playerEntity, null);
            LevelHelper.updateSkill((class_3222) this.playerEntity, SKILLS.get(skillId));
            PacketHelper.updateLevels((class_3222) this.playerEntity);
            return true;
        } else {
            return false;
        }
    }
}
