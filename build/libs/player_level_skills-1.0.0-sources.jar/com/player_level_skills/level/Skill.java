package com.player_level_skills.level;

import java.util.List;
import net.minecraft.class_2561;

public class Skill {

    private final int id;
    private final String key;
    private final int maxLevel;
    private final List<SkillAttribute> attributes;

    public Skill(int id, String key, int maxLevel, List<SkillAttribute> attributes) {
        this.id = id;
        this.key = key;
        this.maxLevel = maxLevel;
        this.attributes = attributes;
    }

    public int getId() {
        return id;
    }

    public String getKey() {
        return key;
    }

    public int getMaxLevel() {
        return maxLevel;
    }

    public List<SkillAttribute> getAttributes() {
        return attributes;
    }

    public class_2561 getText() {
        return class_2561.method_43471("skill.levelz." + key);
    }

}

