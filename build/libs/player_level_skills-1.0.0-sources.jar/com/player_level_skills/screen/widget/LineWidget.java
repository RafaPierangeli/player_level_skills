package com.player_level_skills.screen.widget;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10799;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import com.player_level_skills.Player_level_skills;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.level.restriction.PlayerRestriction;
import com.player_level_skills.mixin.entity.VehicleEntityAccessor;
import com.player_level_skills.registry.EnchantmentRegistry;
import com.player_level_skills.registry.EnchantmentZ;
import com.player_level_skills.screen.PlayerLevelSkillsScreen;
import org.jetbrains.annotations.Nullable;

import java.io.FileNotFoundException;
import java.util.*;

@Environment(EnvType.CLIENT)
public class LineWidget {

    private final class_310 client;
    @Nullable
    private final class_2561 text;
    @Nullable
    private final Map<Integer, PlayerRestriction> restrictions;
    private final int code;

    private Map<Integer, class_1799> customStacks;
    private Map<Integer, class_2960> customImages;

    /**
     * @param code 0 = item, 1 = block, 2 = entity, 3 = enchantment
     */
    public LineWidget(class_310 client, @Nullable class_2561 text, @Nullable Map<Integer, PlayerRestriction> restrictions, int code) {
        this.client = client;
        this.text = text;
        this.restrictions = restrictions;
        this.code = code;

        if (this.code == 2) {
            this.customStacks = new HashMap<>();
            this.customImages = new HashMap<>();
            for (Integer id : this.restrictions.keySet()) {
                class_1299<?> entityType = class_7923.field_41177.method_10200(id);
                boolean imageExists = false;
                try {
                    client.method_1478().getResourceOrThrow(Player_level_skills.identifierOf("textures/gui/sprites/entity/" + class_7923.field_41177.method_10221(entityType).method_12832() + ".png"));
                    imageExists = true;
                } catch (FileNotFoundException ignored) {
                }
                if (imageExists) {
                    this.customImages.put(id, Player_level_skills.identifierOf("textures/gui/sprites/entity/" + class_7923.field_41177.method_10221(entityType).method_12832() + ".png"));
                } else if (class_1826.method_8019(entityType) != null) {
                    this.customStacks.put(id, new class_1799(Objects.requireNonNull(class_1826.method_8019(entityType))));
                } else {
                    this.customImages.put(id, Player_level_skills.identifierOf("textures/gui/sprites/entity/default.png"));
                }
            }
        } else if (this.code == 3) {
            this.customStacks = new HashMap<>();

            for (Integer id : this.restrictions.keySet()) {
                EnchantmentZ enchantmentZ = EnchantmentRegistry.getEnchantmentZ(id);

                class_1799 stack = new class_1799(net.minecraft.class_1802.field_8598);
                class_9304.class_9305 builder = new class_9304.class_9305(class_9304.field_49385);
                builder.method_57550(enchantmentZ.getEntry(), enchantmentZ.getLevel());
                stack.method_57379(class_9334.field_49643, builder.method_57549());

                this.customStacks.put(id, stack);
            }
        }
    }

    public void render(class_332 drawContext, int x, int y, int mouseX, int mouseY) {
        if (text != null) {
            drawContext.method_51439(this.client.field_1772, this.text, x, y + 4, 0xFF3F3F3F, false);
        } else {
            int separator = 0;
            boolean showTooltip = false;
            for (Map.Entry<Integer, PlayerRestriction> entry : this.restrictions.entrySet()) {
                class_2561 tooltipTitle;
                drawContext.method_25290(class_10799.field_56883,PlayerLevelSkillsScreen.ICON_TEXTURE, x + separator - 1, y - 1, 0, 148, 18, 18,256,256);
                if (this.code == 0) {
                    class_1792 item = class_7923.field_41178.method_10200(entry.getKey());
                    tooltipTitle = item.method_63680();
                    drawContext.method_51427(class_7923.field_41178.method_10200(entry.getKey()).method_7854(), x + separator, y);
                } else if (this.code == 1) {
                    class_2248 block = class_7923.field_41175.method_10200(entry.getKey());
                    tooltipTitle = block.method_9518();
                    drawContext.method_51427(block.method_8389().method_7854(), x + separator, y);
                } else if (this.code == 2) {
                    class_1299<?> entityType = class_7923.field_41177.method_10200(entry.getKey());
                    tooltipTitle = entityType.method_5897();
                    if (this.customStacks.containsKey(entry.getKey())) {
                        drawContext.method_51427(this.customStacks.get(entry.getKey()), x + separator, y);
                    } else {
                        drawContext.method_25290(class_10799.field_56883,this.customImages.get(entry.getKey()), x + separator, y, 0, 0, 16, 16,16,16);
                    }
                } else {// if (this.code == 3) {
                    class_1799 stack = this.customStacks.get(entry.getKey());
                    class_6880<class_1887> enchantment = class_1890.method_57532(stack).method_57534().stream().findFirst().get();
                    int level = stack.method_58695(class_9334.field_49643, class_9304.field_49385).method_57536(enchantment);
                    tooltipTitle = class_1887.method_8179(enchantment, level);
                    drawContext.method_51427(stack, x + separator, y);
                }
                if (!showTooltip && PlayerLevelSkillsScreen.isPointWithinBounds(x + separator, y, 16, 16, mouseX, mouseY)) {
                    List<class_2561> tooltip = new ArrayList<>();
                    tooltip.add(tooltipTitle);
                    for (Map.Entry<Integer, Integer> restriction : entry.getValue().getSkillLevelRestrictions().entrySet()) {
                        tooltip.add(class_2561.method_30163(LevelManager.SKILLS.get(restriction.getKey()).getText().getString() + " " + class_2561.method_43469("text.levelz.gui.short_level", restriction.getValue()).getString()));
                    }
                    drawContext.method_51434(this.client.field_1772, tooltip, mouseX, mouseY);
                    showTooltip = true;
                }
                separator += 18;
            }
        }
    }
}

