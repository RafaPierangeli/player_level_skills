package com.player_level_skills.screen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10799;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import com.player_level_skills.Player_level_skills;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.init.KeyInit;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.level.Skill;
import com.player_level_skills.level.SkillBonus;
import com.player_level_skills.level.restriction.PlayerRestriction;
import com.player_level_skills.screen.widget.LineWidget;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

@Environment(EnvType.CLIENT)
public class SkillInfoScreen extends class_437 {

    private static final Logger LOGGER = LogManager.getLogger("LevelZ");

    public static final class_2960 BACKGROUND_TEXTURE = Player_level_skills.identifierOf("textures/gui/skill_info_background.png");

    private final int backgroundWidth = 200;
    private final int backgroundHeight = 215;
    private int x;
    private int y;

    private final List<LineWidget> lines = new ArrayList<>();

    private final Skill skill;
    private final LevelManager levelManager;

    private int lineIndex = 0;

    public SkillInfoScreen(LevelManager levelManager, int skillId) {
        super(LevelManager.SKILLS.get(skillId).getText());
        this.skill = LevelManager.SKILLS.get(skillId);
        this.levelManager = levelManager;
    }

    @Override
    protected void method_25426() {
        super.method_25426();


        this.x = (this.field_22789 - this.backgroundWidth) / 2;
        this.y = (this.field_22790 - this.backgroundHeight) / 2;

        for (int i = 0; i < 50; i++) {
            String skillExtra = "skill.levelz." + this.skill.getKey() + "." + i;
            class_2561 skillExtraText = class_2561.method_43471(skillExtra);
            LOGGER.info("Skill key = {}", this.skill.getKey());
            LOGGER.info("Trying skill text key = {}", skillExtra);
            LOGGER.info("Resolved skill text = {}", skillExtraText.getString());

            if (skillExtraText.getString().equals(skillExtra)) {
                break;
            }
            this.lines.add(new LineWidget(this.field_22787, skillExtraText, null, 0));
        }
        if (!this.lines.isEmpty()) {
            this.lines.addFirst(new LineWidget(this.field_22787, class_2561.method_43471("skill.levelz.info"), null, 0));
        }
        int skillInfoLines = this.lines.size();
        for (String bonusKey : SkillBonus.BONUS_KEYS) {
            if (LevelManager.BONUSES.containsKey(bonusKey)) {
                SkillBonus bonus = LevelManager.BONUSES.get(bonusKey);
                if (bonus.getId() == this.skill.getId()) {
                    for (int i = 0; i < 50; i++) {
                        String bonusInfo = "bonus.levelz." + bonus.getKey() + "." + i;
                        class_2561 bonusInfoText = class_2561.method_43469(bonusInfo, class_2561.method_43469("text.levelz.gui.short_lower_level", bonus.getLevel()));

                        LOGGER.info("Bonus key = {}", bonus.getKey());
                        LOGGER.info("Trying bonus text key = {}", bonusInfo);
                        LOGGER.info("Resolved bonus text = {}", bonusInfoText.getString());

                        if (bonusInfoText.getString().equals(bonusInfo)) {
                            break;
                        }
                        if (bonusInfoText.getString().startsWith("---")) {
                            break;
                        }
                        this.lines.add(new LineWidget(this.field_22787, bonusInfoText, null, 0));
                    }
                }
            }
        }
        if (this.lines.size() > skillInfoLines) {
            this.lines.add(skillInfoLines, new LineWidget(this.field_22787, class_2561.method_43471("bonus.levelz.info"), null, 0));
        }

        addRestrictionLines(LevelManager.ITEM_RESTRICTIONS, class_2561.method_43471("restriction.levelz.item_usage"), 0);
        addRestrictionLines(LevelManager.BLOCK_RESTRICTIONS, class_2561.method_43471("restriction.levelz.block_usage"), 1);
        addRestrictionLines(LevelManager.ENTITY_RESTRICTIONS, class_2561.method_43471("restriction.levelz.entity_usage"), 2);
        addRestrictionLines(LevelManager.ENCHANTMENT_RESTRICTIONS, class_2561.method_43471("restriction.levelz.enchantments"), 3);
    }

    private void addRestrictionLines(Map<Integer, PlayerRestriction> levelRestrictions, class_2561 restrictionText, int code) {
        // Lvl, Id (ex. Item), PlayerRestriction
        Map<Integer, Map<Integer, PlayerRestriction>> map = new TreeMap<>();

        // Id (ex. Item), PlayerRestriction
        for (Map.Entry<Integer, PlayerRestriction> itemRestriction : levelRestrictions.entrySet()) {
            // SkillId, Lvl
            for (Map.Entry<Integer, Integer> specificRestriction : itemRestriction.getValue().getSkillLevelRestrictions().entrySet()) {
                if (specificRestriction.getKey() == this.skill.getId()) {
                    if (map.containsKey(specificRestriction.getValue())) {
                        map.get(specificRestriction.getValue()).put(itemRestriction.getKey(), itemRestriction.getValue());
                    } else {
                        Map<Integer, PlayerRestriction> newMap = new TreeMap<>();
                        newMap.put(itemRestriction.getKey(), itemRestriction.getValue());
                        map.put(specificRestriction.getValue(), newMap);
                    }
                    break;
                }

            }
        }

        if (!map.isEmpty()) {
            this.lines.add(new LineWidget(this.field_22787, restrictionText, null, 0));
        }
        for (Map.Entry<Integer, Map<Integer, PlayerRestriction>> restrictions : map.entrySet()) {
            this.lines.add(new LineWidget(this.field_22787, class_2561.method_43469("text.levelz.gui.short_level", restrictions.getKey()), null, 0));

            if (restrictions.getValue().size() > 10) {
                Map<Integer, PlayerRestriction> newMap = new TreeMap<>();

                int count = 0;
                for (Map.Entry<Integer, PlayerRestriction> specificRestriction : restrictions.getValue().entrySet()) {
                    newMap.put(specificRestriction.getKey(), specificRestriction.getValue());
                    count++;
                    if (count == restrictions.getValue().size()) {
                        this.lines.add(new LineWidget(this.field_22787, null, newMap, code));
                        break;
                    }
                    if (count % 9 == 0) {
                        this.lines.add(new LineWidget(this.field_22787, null, new TreeMap<>(newMap), code));
                        newMap.clear();
                    }
                }
            } else {
                this.lines.add(new LineWidget(this.field_22787, null, restrictions.getValue(), code));
            }
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_51439(this.field_22793, this.field_22785, this.x + 7, this.y + 7, 0xFF3F3F3F, false);
        context.method_51439(this.field_22793, class_2561.method_43469("text.levelz.gui.short_level", this.levelManager.getSkillLevel(this.skill.getId())), this.x + 11 + this.field_22793.method_27525(this.field_22785), this.y + 7, 0xFF3F3F3F, false);

        for (int i = 0; i < 10; i++) {
            if (this.lines.size() <= i) {
                break;
            }
            int index = this.lineIndex + i;

            this.lines.get(index).render(context, this.x + 12, this.y + 24 + i * 18, mouseX, mouseY);
        }
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        method_52752(context);
        context.method_25290(class_10799.field_56883,BACKGROUND_TEXTURE, this.x, this.y, 0, 0, this.backgroundWidth, this.backgroundHeight, 256, 256);

        if (this.lines.size() > 10) {
            int scrollLevels = this.lines.size() - 10;
            int sliderY = this.lineIndex * 156 / scrollLevels;
            context.method_25290(class_10799.field_56883,BACKGROUND_TEXTURE, this.x + 186, this.y + 20 + sliderY, 200, 0, 6, 31,256,256);
        } else {
            context.method_25290(class_10799.field_56883,BACKGROUND_TEXTURE, this.x + 186, this.y + 20, 206, 0, 6, 31,256,256);
        }
        //DrawTabHelper.drawTab(client, context, this, this.x, this.y, mouseX, mouseY);
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (this.field_22787.field_1690.field_1822.method_1417(input)) {
            if (ConfigInit.CONFIG.switchScreen) {
                this.field_22787.method_1507(new PlayerLevelSkillsScreen());
            } else {
                this.method_25419();
            }
            return true;
        } else if (KeyInit.screenKey.method_1417(input)) {
            this.field_22787.method_1507(new PlayerLevelSkillsScreen());
            return true;
        }
        return super.method_25404(input);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.lines.size() > 10 && PlayerLevelSkillsScreen.isPointWithinBounds(this.x + 7, this.y + 19, 186, 189, mouseX, mouseY)) {
            int maxRow = this.lines.size() - 10;
            int newRow = this.lineIndex;
            newRow = newRow - (int) (verticalAmount);
            if (newRow < 0) {
                this.lineIndex = 0;
            } else {
                this.lineIndex = Math.min(newRow, maxRow);
            }
        }

        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

}
