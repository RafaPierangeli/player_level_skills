package com.player_level_skills.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import com.player_level_skills.Player_level_skills;
import com.player_level_skills.access.ClientPlayerAccess;
import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.init.KeyInit;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.level.Skill;
import com.player_level_skills.level.SkillAttribute;
import com.player_level_skills.mixin.player.PlayerEntityAccessor;
import com.player_level_skills.network.packet.AttributeSyncPacket;
import com.player_level_skills.network.packet.StatPacket;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_10185;
import net.minecraft.class_10799;
import net.minecraft.class_1109;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_1304;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_5244;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import java.util.*;

@Environment(EnvType.CLIENT)

public class PlayerLevelSkillsScreen extends class_437 {

    public static final class_2960 BACKGROUND_TEXTURE = class_2960.method_60655(Player_level_skills.MOD_ID, "textures/gui/skill_background.png");

    public static final class_2960 BACKGROUND_TEXTURE2 = class_2960.method_60655(Player_level_skills.MOD_ID, "textures/gui/skill_background2.png");

    public static final class_2960 ATTRIBUTE_BACKGROUND_TEXTURE = class_2960.method_60655(Player_level_skills.MOD_ID, "textures/gui/attribute_background.png");

    public static final class_2960 ICON_TEXTURE = class_2960.method_60655(Player_level_skills.MOD_ID, "textures/gui/icons.png");

    private final int backgroundWidth = 200;
    private final int backgroundHeight = 215;

    private int x;
    private int y;

    private LevelManager levelManager;
    private class_746 clientPlayerEntity;
    private final Quaternionf quaternionf = new Quaternionf().rotateZ((float) Math.PI).rotateLocalY(2.7f);
    private boolean turnClientPlayer = false;


    private List<SkillAttribute> attributes = new ArrayList<>();

    private boolean showAttributes = false;
    private int attributeRow = 0;

    private final WidgetButtonPage[] levelButtons = new WidgetButtonPage[12];
    private int skillRow = 0;

    //private final List<Integer> playerSkills = new ArrayList<>();

    public PlayerLevelSkillsScreen() {
        super(class_2561.method_43471("screen.player_level_skills.title"));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        ClientPlayNetworking.send(new AttributeSyncPacket());

        this.x = (this.field_22789 - this.backgroundWidth) / 2;
        this.y = (this.field_22790 - this.backgroundHeight) / 2;

        class_10185 playerInput = new class_10185(
                false, // forward
                false, // backward
                false, // left
                false, // right
                false, // jumping
                false, // sneaking
                false
        );

        this.levelManager = ((LevelManagerAccess) this.field_22787.field_1724).getLevelManager();
        this.clientPlayerEntity = this.field_22787.field_1761.method_2901(this.field_22787.field_1687, this.field_22787.field_1724.method_3143(), this.field_22787.field_1724.method_3130(),playerInput, false);
        ((ClientPlayerAccess) this.clientPlayerEntity).setShouldRenderClientName(false);
        byte playerModelParts = this.field_22787.field_1724.method_5841().method_12789(PlayerEntityAccessor.getPLAYER_MODEL_PARTS());
        this.clientPlayerEntity.method_5841().method_12778(PlayerEntityAccessor.getPLAYER_MODEL_PARTS(), playerModelParts);

        for (class_1304 equipmentSlot : class_1304.values()) {
            if (!this.field_22787.field_1724.method_6118(equipmentSlot).method_7960()) {
                this.clientPlayerEntity.method_5673(equipmentSlot, this.field_22787.field_1724.method_6118(equipmentSlot));
            }
        }

        Map<Integer, SkillAttribute> skillAttributes = new HashMap<>();
        int attributeCount = 0;
        for (Skill skill : LevelManager.SKILLS.values()) {
            for (SkillAttribute skillAttribute : skill.getAttributes()) {
                if (skillAttribute.getId() < 0) {
                    continue;
                }
                skillAttributes.put(skillAttribute.getId(), skillAttribute);
                attributeCount++;

            }
        }
        for (int i = 0; i < attributeCount; i++) {
            this.attributes.add(skillAttributes.get(i));
        }
        for (int i = 0; i < 12; i++) {
            if (this.levelManager.getPlayerSkills().size() <= i) {
                break;
            }

            final int skillId = i;
            this.levelButtons[i] = this.method_37063(new WidgetButtonPage(this.x + (i % 2 == 0 ? 80 : 169), this.y + 91 + i / 2 * 20, 13, 13, 33, 42, true, true, null, button -> {
                ClientPlayNetworking.send(new StatPacket(this.skillRow * 2 + skillId, 1));
            }));
        }
        updateLevelButtons();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        //this.renderBackground(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);

        if (this.field_22787 != null && this.field_22787.field_1724 != null) {
            class_2561 title = class_2561.method_43469("screen.player_level_skills.player_title", this.field_22787.field_1724.method_5477().getString());
            context.method_51439(this.field_22793, title, this.x + 118 - this.field_22793.method_27525(title) / 2, this.y + 7, 0xFF3F3F3F, false);

            if (!this.attributes.isEmpty()) {
                if (this.showAttributes) {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 5, 30, 114, 15, 13, 256, 256);
                    context.method_25290(class_10799.field_56883, ATTRIBUTE_BACKGROUND_TEXTURE, this.x + 202, this.y, 0, 0, 82, 215, 256, 256);
                    int maxAttributes = Math.min(this.attributes.size(), 15);
                    if (this.attributes.size() > 15) {
                        int scrollLevels = this.attributes.size() - 15;
                        int sliderY = this.attributeRow * 158 / scrollLevels;
                        context.method_25290(class_10799.field_56883, ATTRIBUTE_BACKGROUND_TEXTURE, this.x + 270, this.y + 8 + sliderY, 82, 0, 6, 41, 256, 256);
                    } else {
                        context.method_25290(class_10799.field_56883, ATTRIBUTE_BACKGROUND_TEXTURE, this.x + 270, this.y + 8, 88, 0, 6, 41, 256, 256);
                    }
                    context.method_51439(this.field_22793, class_2561.method_43471("text.levelz.gui.attributes"), this.x + 214, this.y + 12, 0xFFE0E0E0, false);

                    int k = 27;
                    for (int i = this.attributeRow; i < this.attributeRow + maxAttributes; i++) {
                        String attributeKey = this.attributes.get(i).getAttibute().method_55840();
                         if (attributeKey.contains(":")) {
                            attributeKey = attributeKey.split(":")[1];
                        }
                        context.method_25290(class_10799.field_56883,Player_level_skills.identifierOf("textures/gui/sprites/" + attributeKey + ".png"), this.x + 214, this.y + k, 0, 0, 9, 9, 9, 9);
                        float attributeValue = (float) Math.round(this.field_22787.field_1724.method_5996(this.attributes.get(i).getAttibute()).method_6194() * 100.0D) / 100.0F;
                        context.method_51439(this.field_22793, class_2561.method_30163(String.valueOf(attributeValue)), this.x + 214 + 15, this.y + k, 0xFFE0E0E0, false);

                        k += 12;
                    }
                } else {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 5, 15, 114, 15, 13, 256, 256);
                }
                if (isPointWithinBounds(this.x + 178, this.y + 5, 15, 13, mouseX, mouseY)) {
                    context.method_51438(this.field_22793, class_2561.method_43471("text.levelz.gui.attributes"), mouseX, mouseY);
                }
            } else {
                context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 5, 0, 114, 15, 13, 256, 256);
            }

            // Level label
            class_2561 skillLevelText = class_2561.method_43469("text.levelz.gui.level",this.levelManager.getOverallLevel()); // this.levelManager.getOverallLevel()
            context.method_51439(this.field_22793, skillLevelText, this.x + 62, this.y + 42, 0xFF3F3F3F, false);
            // Point label
            class_2561 skillPointText = class_2561.method_43469("text.levelz.gui.points",this.levelManager.getSkillPoints()); //this.levelManager.getSkillPoints()
            context.method_51439(this.field_22793, skillPointText, this.x + 62, this.y + 54, 0xFF3F3F3F, false);

            // Experience bar
            context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 62, this.y + 21, 0, 100, 131, 5, 256, 256);

            int nextLevelExperience = this.levelManager.getNextLevelExperience();
            float levelProgress = this.levelManager.getLevelProgress();
            long experience = (int) (nextLevelExperience * levelProgress);

            context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 62, this.y + 21, 0, 105, (int) (130.0f * levelProgress), 5, 256, 256); // chance 5 to levelProgress
            // current xp label
            class_2561 currentXpText = class_2561.method_43469("text.levelz.gui.current_xp", experience, nextLevelExperience); //, experience, nextLevelExperience
            context.method_51439(this.field_22793, currentXpText, this.x - this.field_22793.method_27525(currentXpText) / 2 + 127, this.y + 30, 0xFF3F3F3F, false);

            if (!LevelManager.CRAFTING_RESTRICTIONS.isEmpty()) {
                if (isPointWithinBounds(this.x + 178, this.y + 29, 14, 13, mouseX, mouseY)) {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 29, 30, 80, 15, 13, 256, 256);
                    context.method_51438(this.field_22793, class_2561.method_43471("restriction.levelz.crafting"), mouseX, mouseY);
                } else {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 29, 15, 80, 15, 13, 256, 256);
                }
            } else {
                context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 29, 0, 80, 15, 13, 256, 256);
            }

            if (!LevelManager.MINING_RESTRICTIONS.isEmpty()) {
                if (isPointWithinBounds(this.x + 178, this.y + 45, 14, 13, mouseX, mouseY)) {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 45, 75, 80, 15, 13, 256, 256);
                    context.method_51438(this.field_22793, class_2561.method_43471("restriction.levelz.mining"), mouseX, mouseY);
                } else {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 45, 60, 80, 15, 13, 256, 256);
                }
            } else {
                context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 45, 45, 80, 15, 13, 256, 256);
            }
        }


        if (this.clientPlayerEntity != null) {
            int x = this.field_22789 / 2;
            int y = this.field_22790 / 2;
            int size = 30; // Base do tamanho
            float scale = 1.0f; // Multiplicador de escala

            class_490.method_2486(context, this.x + 8, this.y-46, this.x + 56,this.y + 76, 30, 1.0f, mouseX, mouseY, this.clientPlayerEntity);


//            if (isPointWithinBounds(this.x + 9, this.y + 67, 15, 10, mouseX, mouseY)) {
//                context.drawTexture(RenderPipelines.GUI_TEXTURED,ICON_TEXTURE, this.x + 9, this.y + 67, 0, 138, 15, 10,256,256);
//            } else {
//                context.drawTexture(RenderPipelines.GUI_TEXTURED,ICON_TEXTURE, this.x + 9, this.y + 67, 0, 128, 15, 10,256,256);
//            }
//            if (isPointWithinBounds(this.x + 41, this.y + 67, 15, 10, mouseX, mouseY)) {
//                context.drawTexture(RenderPipelines.GUI_TEXTURED,ICON_TEXTURE, this.x + 41, this.y + 67, 15, 138, 15, 10,256,256);
//            } else {
//                context.drawTexture(RenderPipelines.GUI_TEXTURED,ICON_TEXTURE, this.x + 41, this.y + 67, 15, 128, 15, 10,256,256);
//            }

        }


    }



    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        method_52752(context);
        context.method_25290(class_10799.field_56883,BACKGROUND_TEXTURE2, this.x, this.y, 0, 0, this.backgroundWidth, this.backgroundHeight,this.backgroundWidth,this.backgroundHeight);

        for (int i = 0; i < 12; i++) {
            int skillId = i + this.skillRow * 2;
            if (LevelManager.SKILLS.size() <= skillId) {
                break;
            }

            context.method_25290(class_10799.field_56883, BACKGROUND_TEXTURE, this.x + (i % 2 == 0 ? 8 : 96), this.y + 87 + i / 2 * 20, 0, 215, 88, 20, 256, 256);
            context.method_25290(class_10799.field_56883, Player_level_skills.identifierOf("textures/gui/sprites/" + LevelManager.SKILLS.get(skillId).getKey() + ".png"), this.x + (i % 2 == 0 ? 11 : 99), this.y + 89 + i / 2 * 20, 0, 0, 16, 16, 16, 16);

            class_2561 skillLevel = class_2561.method_43469("text.levelz.gui.current_level", this.levelManager.getSkillLevel(skillId), LevelManager.SKILLS.get(skillId).getMaxLevel());
            context.method_51439(this.field_22793, skillLevel, this.x + (i % 2 == 0 ? 53 : 141) - this.field_22793.method_27525(skillLevel) / 2, this.y + 94 + i / 2 * 20, 0xFF3F3F3F, false);

            if (isPointWithinBounds(this.x + (i % 2 == 0 ? 11 : 99), this.y + 89 + i / 2 * 20, 16, 16, mouseX, mouseY)) {
                context.method_51438(this.field_22793, LevelManager.SKILLS.get(skillId).getText(), mouseX, mouseY);
            }
        }
        int totalSkills = LevelManager.SKILLS.size();
        if (totalSkills > 12) {
            int scrollLevels = Math.max(1, (int) Math.ceil((totalSkills - 12) / 2.0));
            int sliderY = (int) ((this.skillRow * 86.0f) / scrollLevels);
            context.method_25290(class_10799.field_56883, BACKGROUND_TEXTURE, this.x + 186, this.y + 87 + sliderY, 200, 0, 6, 34, 256, 256);
        } else {
            context.method_25290(class_10799.field_56883, BACKGROUND_TEXTURE, this.x + 186, this.y + 87, 206, 0, 6, 34, 256, 256);
        }
        //DrawTabHelper.drawTab(client, context, this, this.x, this.y, mouseX, mouseY);
    }

//    @Override
//    public void tick() {
//        super.tick();
//        if (this.clientPlayerEntity != null && this.turnClientPlayer) {
//            double mouseX = this.client.mouse.getX() * (double) this.client.getWindow().getScaledWidth() / (double) this.client.getWindow().getWidth();
//            double mouseY = this.client.mouse.getY() * (double) this.client.getWindow().getScaledHeight() / (double) this.client.getWindow().getHeight();
//
//            if (isPointWithinBounds(this.x + 9, this.y + 67, 15, 10, mouseX, mouseY)) {
//                this.quaternionf.rotateLocalY(0.087f);
//            } else if (isPointWithinBounds(this.x + 41, this.y + 67, 15, 10, mouseX, mouseY)) {
//                this.quaternionf.rotateLocalY(-0.087f);
//            } else {
//                this.turnClientPlayer = false;
//            }
//        }
//    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (KeyInit.screenKey.method_1417(input) || Objects.requireNonNull(field_22787).field_1690.field_1822.method_1417(input)) {
            this.method_25419();
            return true;
        }
        return super.method_25404(input);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (this.turnClientPlayer) {
            this.turnClientPlayer = false;
        }
        return false;
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubled) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();

        if (!this.attributes.isEmpty() && isPointWithinBounds(this.x + 178, this.y + 5, 15, 13, mouseX, mouseY)) {
            this.showAttributes = !this.showAttributes;
            this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
            return true;
        }

        if (!LevelManager.CRAFTING_RESTRICTIONS.isEmpty() && isPointWithinBounds(this.x + 178, this.y + 29, 14, 13, mouseX, mouseY)) {
            this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
            this.field_22787.method_1507(new SkillRestrictionScreen(this.levelManager, LevelManager.CRAFTING_RESTRICTIONS, class_2561.method_43471("restriction.levelz.crafting"), 0));
            return true;
        }

        if (!LevelManager.MINING_RESTRICTIONS.isEmpty() && isPointWithinBounds(this.x + 178, this.y + 45, 14, 13, mouseX, mouseY)) {
            this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
            this.field_22787.method_1507(new SkillRestrictionScreen(this.levelManager, LevelManager.MINING_RESTRICTIONS, class_2561.method_43471("restriction.levelz.mining"), 1));
            return true;
        }

//        if (this.clientPlayerEntity != null) {
//            if (isPointWithinBounds(this.x + 9, this.y + 67, 15, 10, mouseX, mouseY)) {
//                this.turnClientPlayer = true;
//                this.client.getSoundManager().play(PositionedSoundInstance.ui(SoundEvents.UI_BUTTON_CLICK, 1.0F));
//                return true;
//            } else if (isPointWithinBounds(this.x + 41, this.y + 67, 15, 10, mouseX, mouseY)) {
//                this.turnClientPlayer = true;
//                this.client.getSoundManager().play(PositionedSoundInstance.ui(SoundEvents.UI_BUTTON_CLICK, 1.0F));
//                return true;
//            }
//        }

        for (int i = 0; i < 12; i++) {
            int skillId = i + this.skillRow * 2;
            if (LevelManager.SKILLS.size() <= skillId) {
                break;
            }

            int iconX = this.x + (i % 2 == 0 ? 11 : 99);
            int iconY = this.y + 89 + i / 2 * 20;

            if (isPointWithinBounds(iconX, iconY, 16, 16, mouseX, mouseY)) {
                this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
                this.field_22787.method_1507(new SkillInfoScreen(this.levelManager, skillId));
                return true;
            }
        }

        return super.method_25402(click, doubled);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.showAttributes && this.attributes.size() > 15 && isPointWithinBounds(this.x + 209, this.y + 7, 68, 201, mouseX, mouseY)) {
            int maxAttributeRow = this.attributes.size() - 15;
            int newAttributeRow = this.attributeRow - (int) verticalAmount;
            this.attributeRow = Math.max(0, Math.min(newAttributeRow, maxAttributeRow));
            return true;
        }

        int totalSkills = LevelManager.SKILLS.size();
        if (totalSkills > 12 && isPointWithinBounds(this.x + 7, this.y + 86, 186, 122, mouseX, mouseY)) {
            int maxSkillRow = Math.max(0, (int) Math.ceil((totalSkills - 12) / 2.0));

            int newSkillRow = this.skillRow - (int) verticalAmount;
            this.skillRow = Math.max(0, Math.min(newSkillRow, maxSkillRow));

            updateLevelButtons();
            return true;
        }

        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!turnClientPlayer) return false;
        return mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        }


    @Override
    public boolean method_25421() {
        return false;
    }

    public void updateLevelButtons() {
        for (int i = 0; i < this.levelButtons.length; i++) {
            int skillId = i + this.skillRow * 2;

            if (LevelManager.SKILLS.size() <= skillId) {
                this.levelButtons[i].field_22764 = false;
                continue;
            } else {
                this.levelButtons[i].field_22764 = true;
            }

            if (ConfigInit.CONFIG.overallMaxLevel > 0 && this.levelManager.getOverallLevel() >= ConfigInit.CONFIG.overallMaxLevel) {
                this.levelButtons[i].field_22763 = false;
            } else if (LevelManager.SKILLS.get(skillId).getMaxLevel() <= this.levelManager.getSkillLevel(skillId)) {
                this.levelButtons[i].field_22763 = false;
            } else {
                this.levelButtons[i].field_22763 = this.levelManager.getSkillPoints() > 0;
            }

            if (ConfigInit.CONFIG.allowHigherSkillLevel && this.levelManager.getSkillPoints() > 0) {
                boolean maxedAllSkills = true;
                for (Skill skillCheck : LevelManager.SKILLS.values()) {
                    if (skillCheck.getMaxLevel() > this.levelManager.getSkillLevel(skillCheck.getId())) {
                        maxedAllSkills = false;
                        break;
                    }
                }
                if (maxedAllSkills) {
                    this.levelButtons[i].field_22763 = true;
                }
            }
        }
    }

    public static boolean isPointWithinBounds(int x, int y, int width, int height, double pointX, double pointY) {
        return pointX >= (double) (x - 1) && pointX < (double) (x + width + 1) && pointY >= (double) (y - 1) && pointY < (double) (y + height + 1);
    }

    private static class WidgetButtonPage extends class_4185 {

        private final boolean hoverOutline;
        private final boolean clickable;
        private final int textureX;
        private final int textureY;
        private final List<class_12231> tooltip = new ArrayList<class_12231>();
        private int clickedKey = -1;

        public WidgetButtonPage(int x, int y, int sizeX, int sizeY, int textureX, int textureY, boolean hoverOutline, boolean clickable, @Nullable class_12231 tooltip, class_4185.class_4241 onPress) {
            super(x, y, sizeX, sizeY, class_5244.field_39003, onPress, field_40754);
            this.hoverOutline = hoverOutline;
            this.clickable = clickable;
            this.textureX = textureX;
            this.textureY = textureY;
            this.field_22758 = sizeX;
            this.field_22759 = sizeY;

            if (tooltip != null) {
                this.tooltip.add(tooltip);
            }
        }

        @Override
        protected void method_75752(class_332 context, int mouseX, int mouseY, float deltaTicks) {
            class_310 minecraftClient = class_310.method_1551();

            context.method_51448().pushMatrix();
            int i = hoverOutline ? this.getTextureY() : 0;
            context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.method_46426(), this.method_46427(), this.textureX + i * this.field_22758, this.textureY, this.field_22758, this.field_22759, 256, 256);
            context.method_51448().popMatrix();

            if (this.method_49606()) {
                context.method_51438(minecraftClient.field_1772, net.minecraft.class_2561.method_43469("text.levelz.gui.up_level", this.tooltip.toString()), mouseX, mouseY);
            }
        }

        //@Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            this.clickedKey = button;
            if (!this.clickable) {
                return false;
            }
            return true;
        }

        @Override
        protected boolean method_25351(class_11910 input) {
            return super.method_25351(input);
        }

        @Override
        public boolean method_25404(class_11908 input) {
            if (!this.clickable) {
                return false;
            }
            return super.method_25404(input);
        }
        public void addTooltip(class_12231 text) {
            this.tooltip.add(text);
        }

        public boolean wasMiddleButtonClicked() {
            return clickedKey == 2;
        }

        public boolean wasRightButtonClicked() {
            return clickedKey == 1;
        }

        private int getTextureY() {
            int i = 1;
            if (!this.field_22763) {
                i = 0;
            } else if (this.method_49606()) {
                i = 2;
            }
            return i;
        }
    }
}