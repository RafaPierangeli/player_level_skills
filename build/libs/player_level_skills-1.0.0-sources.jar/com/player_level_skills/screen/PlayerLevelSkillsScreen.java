package com.player_level_skills.screen;

import com.player_level_skills.Player_level_skills;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.level.SkillAttribute;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10185;
import net.minecraft.class_10799;
import net.minecraft.class_1109;
import net.minecraft.class_11908;
import net.minecraft.class_1304;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_746;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

import java.util.*;

@Environment(EnvType.CLIENT)

public class PlayerLevelSkillsScreen extends class_437 {

    public static final class_2960 BACKGROUND_TEXTURE = class_2960.method_60655(Player_level_skills.MOD_ID, "textures/gui/skill_background.png");

    public static final class_2960 BACKGROUND_TEXTURE2 = class_2960.method_60655(Player_level_skills.MOD_ID, "textures/gui/skill_background2.png");

    public static final class_2960 ATTRIBUTE_BACKGROUND_TEXTURE = class_2960.method_60655(Player_level_skills.MOD_ID, "textures/gui/attribute_background.png");

    public static final class_2960 ICON_TEXTURE = class_2960.method_60655(Player_level_skills.MOD_ID, "textures/gui/icons.png");

    private final int backgroundWidth = 200;
    private final int backgroundHeight = 215;

    private int x;
    private int y;

    private LevelManager levelManager;
    private class_746 clientPlayerEntity;
    private final Quaternionf quaternionf = new Quaternionf().rotateZ((float) Math.PI).rotateLocalY(2.7f);
    private boolean turnClientPlayer = false;

    protected int currentPage = 0;

    private List<SkillAttribute> attributes = new ArrayList<>();

    private boolean showAttributes = false;
    private int attributeRow = 0;

    private final WidgetButtonPage[] levelButtons = new WidgetButtonPage[12];
    private int skillRow = 0;

    private final List<Integer> playerSkills = new ArrayList<>();

    public PlayerLevelSkillsScreen() {
        super(class_2561.method_43471("screen.player_level_skills.title"));
    }

    //ADD Rafa
    public boolean isExpanded() {
        return turnClientPlayer;
    }

    public void toggle() {
        turnClientPlayer = !turnClientPlayer;
        currentPage = 0;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        this.x = (this.field_22789 - this.backgroundWidth) / 2;
        this.y = (this.field_22790 - this.backgroundHeight) / 2;

        if (this.field_22787 != null && this.field_22787.field_1761 != null && this.field_22787.field_1724 != null && this.field_22787.field_1687 != null) {
            class_10185 playerInput = new class_10185(
                    false, // forward
                    false, // backward
                    false, // left
                    false, // right
                    false, // jumping
                    false, // sneaking
                    false
            );

            this.clientPlayerEntity = this.field_22787.field_1761.method_2901(
                    this.field_22787.field_1687,
                    this.field_22787.field_1724.method_3143(),
                    this.field_22787.field_1724.method_3130(),
                    playerInput,
                    false
            );
            //((ClientPlayerAccess) this.clientPlayerEntity).setShouldRenderClientName(false);
            //byte playerModelParts = this.client.player.getDataTracker().get(PlayerEntityAccessor.getPLAYER_MODEL_PARTS());
            //this.clientPlayerEntity.getDataTracker().set(PlayerEntityAccessor.getPLAYER_MODEL_PARTS(), playerModelParts);

            if (this.clientPlayerEntity != null) {
                for (class_1304 equipmentSlot : class_1304.values()) {
                    if (!this.field_22787.field_1724.method_6118(equipmentSlot).method_7960()) {
                        this.clientPlayerEntity.method_5673(equipmentSlot, this.field_22787.field_1724.method_6118(equipmentSlot));
                    }
                }
            }
        }

        if (this.playerSkills.isEmpty()) {
            for (int i = 0; i < 18; i++) {
                this.playerSkills.add(i);
            }
        }

        for (int i = 0; i < 12; i++) {
            if (this.playerSkills.size() <= i) {
                break;
            }

            final int skillId = i;
            this.levelButtons[i] = this.method_37063(
                    new WidgetButtonPage(
                            this.x + (i % 2 == 0 ? 80 : 169),
                            this.y + 91 + i / 2 * 20,
                            13,
                            13,
                            33,
                            42,
                            true,
                            true,
                            null,
                            button -> {
                                assert this.field_22787 != null;
                                this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
                            }
                    )
            );
        }

        updateLevelButtons();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);

        if (this.field_22787 != null && this.field_22787.field_1724 != null) {
            class_2561 title = class_2561.method_43469("screen.player_level_skills.player_title", this.field_22787.field_1724.method_5477().getString());
            context.method_51439(this.field_22793, title, this.x + 118 - this.field_22793.method_27525(title) / 2, this.y + 7, 0xFF3F3F3F, false);

            if (!this.attributes.isEmpty()) {
                if (this.showAttributes) {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 5, 30, 114, 15, 13, 256, 256);
                    context.method_25290(class_10799.field_56883, ATTRIBUTE_BACKGROUND_TEXTURE, this.x + 202, this.y, 0, 0, 82, 215, 200, 215);
                    int maxAttributes = Math.min(this.attributes.size(), 15);
                    if (this.attributes.size() > 15) {
                        int scrollLevels = this.attributes.size() - 15;
                        int sliderY = this.attributeRow * 158 / scrollLevels;
                        context.method_25290(class_10799.field_56883, ATTRIBUTE_BACKGROUND_TEXTURE, this.x + 270, this.y + 8 + sliderY, 82, 0, 6, 41, 256, 256);
                    } else {
                        context.method_25290(class_10799.field_56883, ATTRIBUTE_BACKGROUND_TEXTURE, this.x + 270, this.y + 8, 88, 0, 6, 41, 256, 256);
                    }
                    context.method_51439(this.field_22793, class_2561.method_43471("text.levelz.gui.attributes"), this.x + 214, this.y + 12, 0xFFE0E0E0, false);

                    int k = 27;
                    for (int i = this.attributeRow; i < this.attributeRow + maxAttributes; i++) {
                        String attributeKey = "teste";
                         if (attributeKey.contains(":")) {
                            attributeKey = attributeKey.split(":")[1];
                        }
                        context.method_25290(class_10799.field_56883,Player_level_skills.identifierOf("textures/gui/sprites/" + attributeKey + ".png"), this.x + 214, this.y + k, 0, 0, 9, 9, 9, 9);
                        float attributeValue = 10;
                                //(float) Math.round(this.client.player.getAttributeInstance(this.attributes.get(i).getAttibute()).getValue() * 100.0D) / 100.0F;
                        context.method_51439(this.field_22793, class_2561.method_30163(String.valueOf(attributeValue)), this.x + 214 + 15, this.y + k, 0xFFE0E0E0, false);

                        k += 12;
                    }
                } else {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 5, 15, 114, 15, 13, 256, 256);
                }
                if (isPointWithinBounds(this.x + 178, this.y + 5, 15, 13, mouseX, mouseY)) {
                    context.method_51438(this.field_22793, class_2561.method_43471("text.levelz.gui.attributes"), mouseX, mouseY);
                }
            } else {
                context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 5, 0, 114, 15, 13, 256, 256);
            }

            // Level label
            class_2561 skillLevelText = class_2561.method_43471("text.levelz.gui.level"); // this.levelManager.getOverallLevel()
            context.method_51439(this.field_22793, skillLevelText, this.x + 62, this.y + 42, 0xFF3F3F3F, false);
            // Point label
            class_2561 skillPointText = class_2561.method_43471("text.levelz.gui.points"); //this.levelManager.getSkillPoints()
            context.method_51439(this.field_22793, skillPointText, this.x + 62, this.y + 54, 0xFF3F3F3F, false);

            // Experience bar
            context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 62, this.y + 21, 0, 100, 131, 5, 256, 256);

           // int nextLevelExperience = this.levelManager.getNextLevelExperience();
            //float levelProgress = this.levelManager.getLevelProgress();
            //long experience = (int) (nextLevelExperience * levelProgress);

            context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 62, this.y + 21, 0, 105, (int) (130.0f * 5), 5, 256, 256); // chance 5 to levelProgress
            // current xp label
            class_2561 currentXpText = class_2561.method_43471("text.levelz.gui.current_xp"); //, experience, nextLevelExperience
            context.method_51439(this.field_22793, currentXpText, this.x - this.field_22793.method_27525(currentXpText) / 2 + 127, this.y + 30, 0xFF3F3F3F, false);

            if (!LevelManager.CRAFTING_RESTRICTIONS.isEmpty()) {
                if (isPointWithinBounds(this.x + 178, this.y + 29, 14, 13, mouseX, mouseY)) {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 29, 30, 80, 15, 13, 256, 256);
                    context.method_51438(this.field_22793, class_2561.method_43471("restriction.levelz.crafting"), mouseX, mouseY);
                } else {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 29, 15, 80, 15, 13, 256, 256);
                }
            } else {
                context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 29, 0, 80, 15, 13, 256, 256);
            }

            if (!LevelManager.MINING_RESTRICTIONS.isEmpty()) {
                if (isPointWithinBounds(this.x + 178, this.y + 45, 14, 13, mouseX, mouseY)) {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 45, 75, 80, 15, 13, 256, 256);
                    context.method_51438(this.field_22793, class_2561.method_43471("restriction.levelz.mining"), mouseX, mouseY);
                } else {
                    context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 45, 60, 80, 15, 13, 256, 256);
                }
            } else {
                context.method_25290(class_10799.field_56883, ICON_TEXTURE, this.x + 178, this.y + 45, 45, 80, 15, 13, 256, 256);
            }
        }


        if (this.clientPlayerEntity != null) {

            //InventoryScreen.drawEntity( context, this.x + 33, this.y + 43, 30,30, 30, 30.0f, mouseX, mouseY, this.clientPlayerEntity);

            if (isPointWithinBounds(this.x + 9, this.y + 67, 15, 10, mouseX, mouseY)) {
                context.method_25290(class_10799.field_56883,ICON_TEXTURE, this.x + 9, this.y + 67, 0, 138, 15, 10,256,256);
            } else {
                context.method_25290(class_10799.field_56883,ICON_TEXTURE, this.x + 9, this.y + 67, 0, 128, 15, 10,256,256);
            }
            if (isPointWithinBounds(this.x + 41, this.y + 67, 15, 10, mouseX, mouseY)) {
                context.method_25290(class_10799.field_56883,ICON_TEXTURE, this.x + 41, this.y + 67, 15, 138, 15, 10,256,256);
            } else {
                context.method_25290(class_10799.field_56883,ICON_TEXTURE, this.x + 41, this.y + 67, 15, 128, 15, 10,256,256);
            }

        }


    }



    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        method_52752(context);
        context.method_25290(class_10799.field_56883,BACKGROUND_TEXTURE2, this.x, this.y, 0, 0, this.backgroundWidth, this.backgroundHeight,this.backgroundWidth,this.backgroundHeight);

        for (int i = 0; i < 12; i++) {
            int skillId = i + this.skillRow * 2;
            if (LevelManager.SKILLS.size() <= skillId) {
                break;
            }
            //if (this.levelManager.getPlayerSkills().size() <= skillId) {
            //    break;
            //}
            context.method_25290(class_10799.field_56883,BACKGROUND_TEXTURE, this.x + (i % 2 == 0 ? 8 : 96), this.y + 87 + i / 2 * 20, 0, 215, 88, 20,88,20);
            context.method_25290(class_10799.field_56883,Player_level_skills.identifierOf("textures/gui/sprites/" + LevelManager.SKILLS.get(skillId).getKey() + ".png"), this.x + (i % 2 == 0 ? 11 : 99), this.y + 89 + i / 2 * 20, 0, 0, 16, 16, 16, 16);

            class_2561 skillLevel = class_2561.method_43469("text.levelz.gui.current_level", this.levelManager.getSkillLevel(skillId), LevelManager.SKILLS.get(skillId).getMaxLevel());
            context.method_51439(this.field_22793, skillLevel, this.x + (i % 2 == 0 ? 53 : 141) - this.field_22793.method_27525(skillLevel) / 2, this.y + 94 + i / 2 * 20, 0x3F3F3F, false);

            if (isPointWithinBounds(this.x + (i % 2 == 0 ? 11 : 99), this.y + 89 + i / 2 * 20, 16, 16, mouseX, mouseY)) {
                context.method_51438(this.field_22793, LevelManager.SKILLS.get(skillId).getText(), mouseX, mouseY);
            }
        }
        context.method_25290(class_10799.field_56883,BACKGROUND_TEXTURE, this.x + 186, this.y + 87, 206, 0, 6, 34,6,34);
        //if (this.levelManager.getPlayerSkills().size() > 12) {
        //    int scrollLevels = (this.levelManager.getPlayerSkills().size() - 12) / 2;
        //    if (this.levelManager.getPlayerSkills().size() % 2 != 0) {
        //        scrollLevels += 1;
        //    }
//
         //    int sliderY = this.skillRow * 86 / scrollLevels;
        //    context.drawTexture(RenderPipelines.GUI_TEXTURED,BACKGROUND_TEXTURE, this.x + 186, this.y + 87 + sliderY, 200, 0, 6, 34, 6, 34);
        //} else {
        //    context.drawTexture(RenderPipelines.GUI_TEXTURED,BACKGROUND_TEXTURE, this.x + 186, this.y + 87, 206, 0, 6, 34,6,34);
        //}
        //DrawTabHelper.drawTab(client, context, this, this.x, this.y, mouseX, mouseY);
    }

    @Override
    public void method_25393() {
        super.method_25393();
        if (this.clientPlayerEntity != null && this.turnClientPlayer) {
            double mouseX = this.field_22787.field_1729.method_1603() * (double) this.field_22787.method_22683().method_4486() / (double) this.field_22787.method_22683().method_4480();
            double mouseY = this.field_22787.field_1729.method_1604() * (double) this.field_22787.method_22683().method_4502() / (double) this.field_22787.method_22683().method_4507();

            if (isPointWithinBounds(this.x + 9, this.y + 67, 15, 10, mouseX, mouseY)) {
                this.quaternionf.rotateLocalY(0.087f);
            } else if (isPointWithinBounds(this.x + 41, this.y + 67, 15, 10, mouseX, mouseY)) {
                this.quaternionf.rotateLocalY(-0.087f);
            } else {
                this.turnClientPlayer = false;
            }
        }
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (class_310.method_1551().field_1690.field_1822.method_1417(input)) {
            this.method_25419();
            return true;
        }
        return super.method_25404(input);
    }

    //@Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (this.turnClientPlayer) {
            this.turnClientPlayer = false;
        }
        return false;
    }

    //@Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.attributes.isEmpty() && isPointWithinBounds(this.x + 178, this.y + 5, 15, 13, mouseX, mouseY)) {
            this.showAttributes = !this.showAttributes;
            this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
            return true;
        }

        if (this.clientPlayerEntity != null) {
            if (isPointWithinBounds(this.x + 9, this.y + 67, 15, 10, mouseX, mouseY)) {
                this.turnClientPlayer = true;
                this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
                return true;
            } else if (isPointWithinBounds(this.x + 41, this.y + 67, 15, 10, mouseX, mouseY)) {
                this.turnClientPlayer = true;
                this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
                return true;
            }
        }

        for (int i = 0; i < 12; i++) {
            int skillId = i + this.skillRow * 2;
            if (skillId >= this.playerSkills.size()) {
                break;
            }

            if (isPointWithinBounds(this.x + (i % 2 == 0 ? 11 : 99), this.y + 89 + i / 2 * 20, 16, 16, mouseX, mouseY)) {
                this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.showAttributes && this.attributes.size() > 15 && isPointWithinBounds(this.x + 209, this.y + 7, 68, 201, mouseX, mouseY)) {
            int maxAttributeRow = this.attributes.size() - 15;
            int newAttributeRow = this.attributeRow - (int) verticalAmount;
            if (newAttributeRow < 0) {
                this.attributeRow = 0;
            } else {
                this.attributeRow = Math.min(newAttributeRow, maxAttributeRow);
            }
            return true;
        }

        if (this.playerSkills.size() > 12 && isPointWithinBounds(this.x + 7, this.y + 86, 186, 122, mouseX, mouseY)) {
            int maxSkillRow = (this.playerSkills.size() - 12) / 2;
            if (this.playerSkills.size() % 2 != 0) {
                maxSkillRow += 1;
            }

            int newSkillRow = this.skillRow - (int) verticalAmount;
            if (newSkillRow < 0) {
                this.skillRow = 0;
            } else {
                this.skillRow = Math.min(newSkillRow, maxSkillRow);
            }

            updateLevelButtons();
            return true;
        }

        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (!turnClientPlayer) return false;
        return mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        }


    @Override
    public boolean method_25421() {
        return false;
    }

    public void updateLevelButtons() {
        for (int i = 0; i < this.levelButtons.length; i++) {
            if (this.playerSkills.size() <= i) {
                break;
            }

            int skillId = i + this.skillRow * 2;
            if (skillId >= this.playerSkills.size()) {
                this.levelButtons[i].field_22764 = false;
                return;
            } else {
                this.levelButtons[i].field_22764 = true;
            }

            this.levelButtons[i].field_22763 = true;
        }
    }

    public static boolean isPointWithinBounds(int x, int y, int width, int height, double pointX, double pointY) {
        return pointX >= (double) (x - 1) && pointX < (double) (x + width + 1) && pointY >= (double) (y - 1) && pointY < (double) (y + height + 1);
    }

    private static class WidgetButtonPage extends class_4185 {

        private final boolean hoverOutline;
        private final boolean clickable;
        private final int textureX;
        private final int textureY;
        private final List<class_12231> tooltip = new ArrayList<>();
        private int clickedKey = -1;

        public WidgetButtonPage(int x, int y, int sizeX, int sizeY, int textureX, int textureY, boolean hoverOutline, boolean clickable, @Nullable class_12231 tooltip, class_4185.class_4241 onPress) {
            super(x, y, sizeX, sizeY, class_5244.field_39003, onPress, field_40754);
            this.hoverOutline = hoverOutline;
            this.clickable = clickable;
            this.textureX = textureX;
            this.textureY = textureY;
            this.field_22758 = sizeX;
            this.field_22759 = sizeY;

            if (tooltip != null) {
                this.tooltip.add(tooltip);
            }
        }

        @Override
        protected void method_75752(class_332 context, int mouseX, int mouseY, float delta) {
            class_310 minecraftClient = class_310.method_1551();
            context.method_25290(
                    class_10799.field_56883,
                    ICON_TEXTURE,
                    this.method_46426(),
                    this.method_46427(),
                    this.textureX + this.getTextureY() * this.field_22758,
                    this.textureY,
                    this.field_22758,
                    this.field_22759,
                    200,
                    215
            );

            if (this.method_49606()) {
                //context.drawTooltip(minecraftClient.textRenderer, this.tooltip, mouseX, mouseY);
            }
        }


        //@Override
       // public boolean mouseClicked(double mouseX, double mouseY, int button) {
       //     this.clickedKey = button;
        //    if (!this.clickable) {
       //         return false;
        //    }
         //   return super.mouseClicked(mouseX, mouseY, button);
       // }

        //@Override
        //protected boolean isValidClickButton(int button) {
        //    return super.isValidClickButton(button) || button == 1 || button == 2;
        //}

        //@Override
        //public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        //    if (!this.clickable) {
        //        return false;
        //    }
        //    return super.keyPressed(keyCode, scanCode, modifiers);
        //}

        public boolean wasMiddleButtonClicked() {
            return clickedKey == 2;
        }

        public boolean wasRightButtonClicked() {
            return clickedKey == 1;
        }

        private int getTextureY() {
            int i = 1;
            if (!this.field_22763) {
                i = 0;
            } else if (this.method_49606()) {
                i = 2;
            }
            return i;
        }
    }
}