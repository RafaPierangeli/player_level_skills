package com.player_level_skills.screen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10799;
import net.minecraft.class_1109;
import net.minecraft.class_11908;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import com.player_level_skills.Player_level_skills;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.init.KeyInit;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.level.restriction.PlayerRestriction;
import com.player_level_skills.screen.widget.LineWidget;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Environment(EnvType.CLIENT)
public class SkillRestrictionScreen extends class_437 {

    public static final class_2960 BACKGROUND_TEXTURE = Player_level_skills.identifierOf("textures/gui/skill_info_background.png");

    private final int backgroundWidth = 200;
    private final int backgroundHeight = 215;
    private int x;
    private int y;

    private final List<LineWidget> lines = new ArrayList<>();

    private final LevelManager levelManager;
    private Map<Integer, PlayerRestriction> restrictions;
    private final class_2561 title;
    private final int code;

    private int lineIndex = 0;
    private boolean sortAlphabetical = false;

    public SkillRestrictionScreen(LevelManager levelManager, Map<Integer, PlayerRestriction> restrictions, class_2561 title, int code) {
        super(title);
        this.levelManager = levelManager;
        this.restrictions = restrictions;
        this.field_22785 = title;
        this.code = code;
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        this.x = (this.field_22789 - this.backgroundWidth) / 2;
        this.y = (this.field_22790 - this.backgroundHeight) / 2;

        sortRestrictions();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_51439(this.field_22793, this.field_22785, this.x + 7, this.y + 7, 0x3F3F3F, false);

        for (int i = 0; i < 10; i++) {
            if (this.lines.size() <= i) {
                break;
            }
            int index = this.lineIndex + i;

            this.lines.get(index).render(context, this.x + 12, this.y + 24 + i * 18, mouseX, mouseY);
        }
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        method_52752(context);
        context.method_25290(class_10799.field_56883,BACKGROUND_TEXTURE, this.x, this.y, 0, 0, this.backgroundWidth, this.backgroundHeight, 256, 256);

        if (this.lines.size() > 10) {
            int scrollLevels = this.lines.size() - 10;
            int sliderY = this.lineIndex * 156 / scrollLevels;
            context.method_25290(class_10799.field_56883,BACKGROUND_TEXTURE, this.x + 186, this.y + 20 + sliderY, 200, 0, 6, 31,256,256);
        } else {
            context.method_25290(class_10799.field_56883,BACKGROUND_TEXTURE, this.x + 186, this.y + 20, 206, 0, 6, 31,256,256);
        }
        int sortU = PlayerLevelSkillsScreen.isPointWithinBounds(this.x + 179, this.y + 4, 14, 14, mouseX, mouseY) ? 14 : 0;
        int sortV = this.sortAlphabetical ? 180 : 166;
        context.method_25290(class_10799.field_56883,PlayerLevelSkillsScreen.ICON_TEXTURE, this.x + 179, this.y + 4, sortU, sortV, 14, 14,256,256);

        //DrawTabHelper.drawTab(client, context, this, this.x, this.y, mouseX, mouseY);
    }

    @Override
    public boolean method_25404(class_11908 input) {
        if (this.field_22787.field_1690.field_1822.method_1417(input)) {
            if (ConfigInit.CONFIG.switchScreen) {
                this.field_22787.method_1507(new PlayerLevelSkillsScreen());
            } else {
                this.method_25419();
            }
            return true;

        } else if (KeyInit.screenKey.method_1417(input)) {
            this.field_22787.method_1507(new PlayerLevelSkillsScreen());
            return true;
        }
        return super.method_25404(input);
    }

    //@Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        //DrawTabHelper.onTabButtonClick(client, this, this.x, this.y, mouseX, mouseY, false);
        if (PlayerLevelSkillsScreen.isPointWithinBounds(this.x + 179, this.y + 4, 14, 14, mouseX, mouseY)) {
            this.sortAlphabetical = !this.sortAlphabetical;
            sortRestrictions();
            this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (this.lines.size() > 10 && PlayerLevelSkillsScreen.isPointWithinBounds(this.x + 7, this.y + 19, 186, 189, mouseX, mouseY)) {
            int maxRow = this.lines.size() - 10;
            int newRow = this.lineIndex;
            newRow = newRow - (int) (verticalAmount);
            if (newRow < 0) {
                this.lineIndex = 0;
            } else {
                this.lineIndex = Math.min(newRow, maxRow);
            }
        }

        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    private void sortRestrictions() {
        if (this.code == 0) {
            if (this.sortAlphabetical) {
                this.restrictions = this.restrictions.entrySet().stream()
                        .sorted((entry1, entry2) -> {
                            String itemName1 = class_7923.field_41178.method_10200(entry1.getKey()).method_63680().getString();
                            String itemName2 = class_7923.field_41178.method_10200(entry2.getKey()).method_63680().getString();
                            return itemName1.compareToIgnoreCase(itemName2);
                        }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
            } else {
                this.restrictions = this.restrictions.entrySet().stream()
                        .sorted((entry1, entry2) -> {
                            int itemVar1 = entry1.getValue().getSkillLevelRestrictions().values().stream().findFirst().get();
                            int itemVar2 = entry2.getValue().getSkillLevelRestrictions().values().stream().findFirst().get();
                            return Integer.compare(itemVar1, itemVar2);
                        }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
            }
        } else {
            if (this.sortAlphabetical) {
                this.restrictions = this.restrictions.entrySet().stream()
                        .sorted((entry1, entry2) -> {
                            String itemName1 = class_7923.field_41175.method_10200(entry1.getKey()).method_9518().getString();
                            String itemName2 = class_7923.field_41175.method_10200(entry2.getKey()).method_9518().getString();
                            return itemName1.compareToIgnoreCase(itemName2);
                        }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
            } else {
                this.restrictions = this.restrictions.entrySet().stream()
                        .sorted((entry1, entry2) -> {
                            int itemVar1 = entry1.getValue().getSkillLevelRestrictions().values().stream().findFirst().get();
                            int itemVar2 = entry2.getValue().getSkillLevelRestrictions().values().stream().findFirst().get();
                            return Integer.compare(itemVar1, itemVar2);
                        }).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
            }
        }
        this.lines.clear();

        int count = 0;
        Map<Integer, PlayerRestriction> newMap = new LinkedHashMap<>();
        for (Map.Entry<Integer, PlayerRestriction> entry : this.restrictions.entrySet()) {
            newMap.put(entry.getKey(), entry.getValue());
            count++;
            if (count == this.restrictions.size() - 1) {
                this.lines.add(new LineWidget(this.field_22787, null, newMap, code));
                break;
            }
            if (count != 0 && count % 9 == 0) {
                this.lines.add(new LineWidget(this.field_22787, null, new LinkedHashMap<>(newMap), code));
                newMap.clear();
            }

        }
    }

}

