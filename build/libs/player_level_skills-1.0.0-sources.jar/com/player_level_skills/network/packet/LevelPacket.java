package com.player_level_skills.network.packet;

import com.player_level_skills.Player_level_skills;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record LevelPacket(int overallLevel, int skillPoints, int totalLevelExperience, float levelProgress) implements class_8710 {

    public static final class_8710.class_9154<LevelPacket> PACKET_ID = new class_8710.class_9154<>(Player_level_skills.identifierOf("level_packet"));

    public static final class_9139<class_9129, LevelPacket> PACKET_CODEC = class_9139.method_56438((value, buf) -> {
        buf.method_53002(value.overallLevel);
        buf.method_53002(value.skillPoints);
        buf.method_53002(value.totalLevelExperience);
        buf.method_52941(value.levelProgress);
    }, buf -> new LevelPacket(buf.readInt(), buf.readInt(), buf.readInt(), buf.readFloat()));

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}


