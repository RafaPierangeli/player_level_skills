package com.player_level_skills.network.packet;

import com.player_level_skills.access.OrbAccess;
import com.player_level_skills.entity.LevelExperienceOrbEntity;
import com.player_level_skills.network.LevelServerPacket;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_3231;
import net.minecraft.class_9139;
import net.minecraft.class_9145;

public class OrbPacket implements class_2596<class_2602> {
    public static final class_9139<class_2540, OrbPacket> CODEC = class_2596.method_56443(OrbPacket::write, OrbPacket::new);
    private final int entityId;
    private final double x;
    private final double y;
    private final double z;
    private final int experience;

    public OrbPacket(LevelExperienceOrbEntity orb, class_3231 entry) {
        this.entityId = orb.method_5628();
        class_243 vec3d = entry.method_60942();
        this.x = vec3d.method_10216();
        this.y = vec3d.method_10214();
        this.z = vec3d.method_10215();
        this.experience = orb.getExperienceAmount();
    }

    private OrbPacket(class_2540 buf) {
        this.entityId = buf.method_10816();
        this.x = buf.readDouble();
        this.y = buf.readDouble();
        this.z = buf.readDouble();
        this.experience = buf.readShort();
    }

    private void write(class_2540 buf) {
        buf.method_10804(this.entityId);
        buf.method_52940(this.x);
        buf.method_52940(this.y);
        buf.method_52940(this.z);
        buf.method_52998(this.experience);
    }


    public class_9145<OrbPacket> getPacketId() {
        return LevelServerPacket.ADD_LEVEL_EXPERIENCE_ORB;
    }

    @Override
    public class_9145<? extends class_2596<class_2602>> method_65080() {
        return null;
    }

    public void apply(class_2602 clientPlayPacketListener) {
        ((OrbAccess) clientPlayPacketListener).onLevelExperienceOrbSpawn(this);
    }

    public int getEntityId() {
        return this.entityId;
    }

    public double getX() {
        return this.x;
    }

    public double getY() {
        return this.y;
    }

    public double getZ() {
        return this.z;
    }

    public int getExperience() {
        return this.experience;
    }
}
//
//
////package net.levelz.network.packet;
////
////import net.levelz.LevelzMain;
////import net.minecraft.network.RegistryByteBuf;
////import net.minecraft.network.codec.PacketCodec;
////import net.minecraft.network.packet.CustomPayload;
////
////public record OrbPacket(int id, double x, double y, double z, int amount) implements CustomPayload {
////
////    public static final CustomPayload.Id<OrbPacket> PACKET_ID = new CustomPayload.Id<>(LevelzMain.identifierOf("orb_packet"));
////
////    public static final PacketCodec<RegistryByteBuf, OrbPacket> PACKET_CODEC = PacketCodec.of((value, buf) -> {
////        buf.writeInt(value.id);
////        buf.writeDouble(value.x);
////        buf.writeDouble(value.y);
////        buf.writeDouble(value.z);
////        buf.writeInt(value.amount);
////    }, buf -> new OrbPacket(buf.readInt(), buf.readDouble(), buf.readDouble(), buf.readDouble(), buf.readInt()));
////
////    @Override
////    public Id<? extends CustomPayload> getId() {
////        return PACKET_ID;
////    }
////
////}
////
