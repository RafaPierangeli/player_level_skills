package com.player_level_skills.network.packet;

import com.player_level_skills.Player_level_skills;
import java.util.List;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record PlayerSkillSyncPacket(List<Integer> playerSkillIds, List<Integer> playerSkillLevels) implements class_8710 {

    public static final class_8710.class_9154<PlayerSkillSyncPacket> PACKET_ID = new class_8710.class_9154<>(Player_level_skills.identifierOf("player_skill_sync_packet"));

    public static final class_9139<class_9129, PlayerSkillSyncPacket> PACKET_CODEC = class_9139.method_56438((value, buf) -> {
        buf.method_34062(value.playerSkillIds, class_2540::method_53002);
        buf.method_34062(value.playerSkillLevels, class_2540::method_53002);
    }, buf -> new PlayerSkillSyncPacket(buf.method_34066(class_2540::readInt), buf.method_34066(class_2540::readInt)));

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}