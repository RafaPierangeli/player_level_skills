package com.player_level_skills.network.packet;


import com.player_level_skills.Player_level_skills;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Increase skill packet
 * Used in the skill screen by using a button
 *
 * @param id    skill id
 * @param level amount
 */
public record StatPacket(int id, int level) implements class_8710 {

    public static final class_8710.class_9154<StatPacket> PACKET_ID = new class_8710.class_9154<>(Player_level_skills.identifierOf("stat_packet"));

    public static final class_9139<class_9129, StatPacket> PACKET_CODEC = class_9139.method_56438((value, buf) -> {
        buf.method_53002(value.id);
        buf.method_53002(value.level);
    }, buf -> new StatPacket(buf.readInt(), buf.readInt()));

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}
