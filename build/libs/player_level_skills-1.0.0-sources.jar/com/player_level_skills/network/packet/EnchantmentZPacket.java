package com.player_level_skills.network.packet;

import com.player_level_skills.Player_level_skills;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record EnchantmentZPacket(Map<String, Integer> indexed, List<Integer> keys, List<String> ids, List<Integer> levels) implements class_8710 {

    public static final class_8710.class_9154<EnchantmentZPacket> PACKET_ID = new class_8710.class_9154<>(Player_level_skills.identifierOf("enchantmentz_packet"));

    public static final class_9139<class_9129, EnchantmentZPacket> PACKET_CODEC = class_9139.method_56438((value, buf) -> {
        buf.method_34063(value.indexed, class_2540::method_10814, class_2540::method_53002);
        buf.method_34062(value.keys, class_2540::method_53002);
        buf.method_34062(value.ids, class_2540::method_10814);
        buf.method_34062(value.levels, class_2540::method_53002);
    }, buf -> new EnchantmentZPacket(buf.method_34067(class_2540::method_19772, class_2540::readInt), buf.method_34066(class_2540::readInt), buf.method_34066(class_2540::method_19772), buf.method_34066(class_2540::readInt)));

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}


