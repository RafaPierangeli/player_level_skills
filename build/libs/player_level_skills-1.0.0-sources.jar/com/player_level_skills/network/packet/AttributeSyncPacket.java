package com.player_level_skills.network.packet;

import com.player_level_skills.Player_level_skills;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record AttributeSyncPacket() implements class_8710 {

    public static final class_8710.class_9154<AttributeSyncPacket> PACKET_ID = new class_8710.class_9154<>(Player_level_skills.identifierOf("attribute_sync_packet"));

    public static final class_9139<class_9129, AttributeSyncPacket> PACKET_CODEC = class_9139.method_56438((value, buf) -> {
    }, buf -> new AttributeSyncPacket());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return PACKET_ID;
    }

}


