package com.player_level_skills.access;

import net.minecraft.class_2791;

public interface PlayerDropAccess {

    void increaseKilledMobStat(class_2791 chunk);

    boolean allowMobDrop();

    void resetKilledMobStat();
}
