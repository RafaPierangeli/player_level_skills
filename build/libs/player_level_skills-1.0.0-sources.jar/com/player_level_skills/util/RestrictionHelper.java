package com.player_level_skills.util;

//import io.wispforest.accessories.menu.variants.AccessoriesMenuBase;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.level.LevelManager;

public class RestrictionHelper {

    private static final boolean isAccessoriesLoaded = FabricLoader.getInstance().isModLoaded("accessories");

    public static boolean restrictSlotClick(class_1657 playerEntity, class_1713 actionType, class_1799 cursorStack, class_1735 slot, class_1703 screenHandler) {
        if (!playerEntity.method_68878()) {
            LevelManager levelManager = ((LevelManagerAccess) playerEntity).getLevelManager();
            if (actionType.equals(class_1713.field_7794)) {
                return !slot.method_7677().method_7960() && !levelManager.hasRequiredItemLevel(slot.method_7677().method_7909());
            } else if (!cursorStack.method_7960()) {
                boolean isNonNormalSlot = !slot.getClass().equals(class_1735.class);
                if (!levelManager.hasRequiredItemLevel(cursorStack.method_7909())) {
                    if (screenHandler instanceof class_1723) {
                        if (isNonNormalSlot) {
                            return true;
                        }
//                    } else if (isAccessoriesLoaded && screenHandler instanceof AccessoriesMenuBase) {
//                        if (isNonNormalSlot) {
//                            return true;
//                        }
                    }
                }
                if (!levelManager.hasRequiredCraftingLevel(cursorStack.method_7909()) && isNonNormalSlot) {
                    return true;
                }
            }
        }

        return false;
    }
}
