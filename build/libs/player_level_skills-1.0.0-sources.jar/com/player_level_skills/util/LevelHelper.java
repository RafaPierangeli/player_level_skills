package com.player_level_skills.util;

import com.player_level_skills.Player_level_skills;
import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.level.Skill;
import com.player_level_skills.level.SkillAttribute;
import net.minecraft.class_1322;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class LevelHelper {

    public static void updateSkill(class_3222 serverPlayerEntity, Skill skill) {
        LevelManager levelManager = ((LevelManagerAccess) serverPlayerEntity).getLevelManager();
        for (SkillAttribute skillAttribute : skill.getAttributes()) {
            if (serverPlayerEntity.method_5996(skillAttribute.getAttibute()) != null) {
                if (skillAttribute.getBaseValue() > -9999.0f) {
                    serverPlayerEntity.method_5996(skillAttribute.getAttibute()).method_6192(skillAttribute.getBaseValue());
                }
                class_2960 identifier = Player_level_skills.identifierOf(skill.getKey());
                if (serverPlayerEntity.method_5996(skillAttribute.getAttibute()).method_6196(identifier)) {
                    serverPlayerEntity.method_5996(skillAttribute.getAttibute()).method_6200(identifier);
                }
                serverPlayerEntity.method_5996(skillAttribute.getAttibute()).method_26835(new class_1322(identifier, skillAttribute.getLevelValue() * levelManager.getSkillLevel(skill.getId()), skillAttribute.getOperation()));
            }
        }
    }
}
