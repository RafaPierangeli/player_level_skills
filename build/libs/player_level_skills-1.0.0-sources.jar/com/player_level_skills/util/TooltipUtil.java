package com.player_level_skills.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mojang.blaze3d.systems.RenderSystem;
import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.level.restriction.PlayerRestriction;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_2248;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_7923;
import net.minecraft.client.render.*;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

public class TooltipUtil {

    public static void renderItemTooltip(class_310 client, class_1799 stack, List<class_2561> lines) {
        if (client.field_1724 != null) {
            LevelManager levelManager = ((LevelManagerAccess) client.field_1724).getLevelManager();
            boolean isCreative = client.field_1724.method_68878(); // Add all lines, not only the missing ones

            if (stack.method_7909() instanceof class_1747 blockItem) {
                int blockId = class_7923.field_41175.method_10206(blockItem.method_7711());
                if (isCreative || !levelManager.hasRequiredBlockLevel(blockItem.method_7711())) {
                    if (LevelManager.BLOCK_RESTRICTIONS.containsKey(blockId)) {
                        PlayerRestriction playerRestriction = LevelManager.BLOCK_RESTRICTIONS.get(blockId);
                        lines.add(class_2561.method_43471("restriction.levelz.usable.tooltip"));
                        for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
                            if (isCreative || levelManager.getSkillLevel(entry.getKey()) < entry.getValue()) {
                                lines.add(class_2561.method_43469("restriction.levelz." + LevelManager.SKILLS.get(entry.getKey()).getKey() + ".tooltip", entry.getValue()).method_27692(class_124.field_1061));
                            }
                        }
                    }
                }
                if (isCreative || !levelManager.hasRequiredMiningLevel(blockItem.method_7711())) {
                    if (LevelManager.MINING_RESTRICTIONS.containsKey(blockId)) {
                        PlayerRestriction playerRestriction = LevelManager.MINING_RESTRICTIONS.get(blockId);
                        lines.add(class_2561.method_43471("restriction.levelz.mineable.tooltip"));
                        for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
                            if (isCreative || levelManager.getSkillLevel(entry.getKey()) < entry.getValue()) {
                                lines.add(class_2561.method_43469("restriction.levelz." + LevelManager.SKILLS.get(entry.getKey()).getKey() + ".tooltip", entry.getValue()).method_27692(class_124.field_1061));
                            }
                        }
                    }
                }
            }
            int itemId = class_7923.field_41178.method_10206(stack.method_7909());
            if (isCreative || !levelManager.hasRequiredItemLevel(stack.method_7909())) {
                if (LevelManager.ITEM_RESTRICTIONS.containsKey(itemId)) {
                    PlayerRestriction playerRestriction = LevelManager.ITEM_RESTRICTIONS.get(itemId);
                    lines.add(class_2561.method_43471("restriction.levelz.usable.tooltip"));
                    for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
                        if (isCreative || levelManager.getSkillLevel(entry.getKey()) < entry.getValue()) {
                            lines.add(class_2561.method_43469("restriction.levelz." + LevelManager.SKILLS.get(entry.getKey()).getKey() + ".tooltip", entry.getValue()).method_27692(class_124.field_1061));
                        }
                    }
                }
            }
            if (isCreative || !levelManager.hasRequiredCraftingLevel(stack.method_7909())) {
                if (LevelManager.CRAFTING_RESTRICTIONS.containsKey(itemId)) {
                    PlayerRestriction playerRestriction = LevelManager.CRAFTING_RESTRICTIONS.get(itemId);
                    lines.add(class_2561.method_43471("restriction.levelz.craftable.tooltip"));
                    for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
                        if (isCreative || levelManager.getSkillLevel(entry.getKey()) < entry.getValue()) {
                            lines.add(class_2561.method_43469("restriction.levelz." + LevelManager.SKILLS.get(entry.getKey()).getKey() + ".tooltip", entry.getValue()).method_27692(class_124.field_1061));
                        }
                    }
                }
            }
            if (stack.method_7909() instanceof class_1826 spawnEggItem) {
                if (isCreative || !levelManager.hasRequiredEntityLevel(spawnEggItem.method_8015(stack))) {
                    int entityId = class_7923.field_41177.method_10206(spawnEggItem.method_8015(stack));
                    if (LevelManager.ENTITY_RESTRICTIONS.containsKey(entityId)) {
                        PlayerRestriction playerRestriction = LevelManager.ENTITY_RESTRICTIONS.get(entityId);
                        lines.add(class_2561.method_43471("restriction.levelz.usable.tooltip"));
                        for (Map.Entry<Integer, Integer> entry : playerRestriction.getSkillLevelRestrictions().entrySet()) {
                            if (isCreative || levelManager.getSkillLevel(entry.getKey()) < entry.getValue()) {
                                lines.add(class_2561.method_43469("restriction.levelz." + LevelManager.SKILLS.get(entry.getKey()).getKey() + ".tooltip", entry.getValue()).method_27692(class_124.field_1061));
                            }
                        }
                    }
                }
            }
        }
    }

    // Recommend to play with https://www.curseforge.com/minecraft/mc-mods/health-overlay-fabric
    public static void renderTooltip(class_310 client, class_332 context) {
        if (client.field_1765 != null && ConfigInit.CONFIG.showLockedBlockInfo) {

            class_239 hitResult = client.field_1765;
            if (hitResult.method_17783() == class_239.class_240.field_1331) {
                LevelManager levelManager = ((LevelManagerAccess) client.field_1724).getLevelManager();
                class_1299<?> entityType = ((class_3966) hitResult).method_17782().method_5864();
                if (!levelManager.hasRequiredEntityLevel(entityType)) {
                    List<class_2561> textList = new ArrayList<>();
                    textList.add(class_2561.method_30163(entityType.method_5897().getString()));
                    for (Map.Entry<Integer, Integer> entry : levelManager.getRequiredEntityLevel(entityType).entrySet()) {
                        class_124 formatting =
                                levelManager.getSkillLevel(entry.getKey()) < entry.getValue() ? class_124.field_1061 : class_124.field_1060;
                        textList.add(class_2561.method_43469("restriction.levelz." + LevelManager.SKILLS.get(entry.getKey()).getKey() + ".tooltip", entry.getValue()).method_27692(formatting));
                    }
                    renderTooltip(client, context, textList,
                            null, context.method_51421() / 2 + ConfigInit.CONFIG.lockedBlockInfoPosX, ConfigInit.CONFIG.lockedBlockInfoPosY);
                }
            } else if (hitResult.method_17783() == class_239.class_240.field_1332) {
                class_2248 block = client.field_1687.method_8320(((class_3965) hitResult).method_17777()).method_26204();
                LevelManager levelManager = ((LevelManagerAccess) client.field_1724).getLevelManager();
                List<class_2561> textList = new ArrayList<>();
                if (!levelManager.hasRequiredMiningLevel(block)) {
                    textList.add(class_2561.method_30163(block.method_9518().getString()));
                    // textList.add(Text.translatable("item.levelz.mineable.tooltip"));
                    for (Map.Entry<Integer, Integer> entry : levelManager.getRequiredMiningLevel(block).entrySet()) {
                        class_124 formatting =
                                levelManager.getSkillLevel(entry.getKey()) < entry.getValue() ? class_124.field_1061 : class_124.field_1060;
                        textList.add(class_2561.method_43469("restriction.levelz." + LevelManager.SKILLS.get(entry.getKey()).getKey() + ".tooltip", entry.getValue()).method_27692(formatting));
                    }
                }
                if (!levelManager.hasRequiredBlockLevel(block)) {
                    if (textList.isEmpty()) {
                        textList.add(class_2561.method_30163(block.method_9518().getString()));
                    }
                    textList.add(class_2561.method_43471("restriction.levelz.block_usage"));
                    for (Map.Entry<Integer, Integer> entry : levelManager.getRequiredBlockLevel(block).entrySet()) {
                        class_124 formatting =
                                levelManager.getSkillLevel(entry.getKey()) < entry.getValue() ? class_124.field_1061 : class_124.field_1060;
                        textList.add(class_2561.method_43469("restriction.levelz." + LevelManager.SKILLS.get(entry.getKey()).getKey() + ".tooltip", entry.getValue()).method_27692(formatting));
                    }
                }
                if (!textList.isEmpty()) {
                    renderTooltip(client, context, textList,
                            class_7923.field_41175.method_10221(block), context.method_51421() / 2 + ConfigInit.CONFIG.lockedBlockInfoPosX, ConfigInit.CONFIG.lockedBlockInfoPosY);
                }
            }
        }
    }

    private static void renderTooltip(class_310 client, class_332 context, List<class_2561> textList, @Nullable class_2960 identifier, int x, int y) {
        int maxTextWidth = 0;
        for (int i = 0; i < textList.size(); i++) {
            if (client.field_1772.method_27525(textList.get(i)) > maxTextWidth) {
                maxTextWidth = client.field_1772.method_27525(textList.get(i));
                if (i == 0 && identifier != null) {
                    maxTextWidth += 22;
                }
            }
        }
        maxTextWidth += 5;

        context.method_51448().pushMatrix();

        int colorStart = 0xBF191919; // background
        int colorTwo = 0xBF7F0200; // light border
        int colorThree = 0xBF380000; // darker border

        render(context, x - maxTextWidth / 2 - 3, y + 4, maxTextWidth, textList.size() * 10 + 11, 400, colorStart, colorTwo, colorThree);

        context.method_51448().translate(0.0F, 0.0F);

        int i = 9;
        for (class_2561 text : textList) {
            if (i == 9) {
                context.method_51439(client.field_1772, text, x - maxTextWidth / 2 + (identifier != null ? 20 : 0), y + i, 0xFFFFFFFF, false);
            } else {
                context.method_51439(client.field_1772, text, x - maxTextWidth / 2, y + i + 8, 0xFFFFFFFF, false);
            }
            i += 10;
        }

        if (identifier != null) {
            context.method_51427(class_7923.field_41178.method_63535(identifier).method_7854(), x - maxTextWidth / 2, y + 5);
        }
        context.method_51448().popMatrix();
    }

    public static void render(class_332 context, int x, int y, int width, int height, int z, int background, int borderColorStart, int borderColorEnd) {
        int i = x - 3;
        int j = y - 3;
        int k = width + 3 + 3;
        int l = height + 3 + 3;

        renderHorizontalLine(context, i, j - 1, k, z, background);
        renderHorizontalLine(context, i, j + l, k, z, background);
        renderRectangle(context, i, j, k, l, z, background);
        renderVerticalLine(context, i - 1, j, l, z, background);
        renderVerticalLine(context, i + k, j, l, z, background);
        renderBorder(context, i, j + 1, k, l, z, borderColorStart, borderColorEnd);

        width -= 6;
        renderHorizontalLine(context, z, x + 3, y + 19, x + 3 + width / 2, y + 20, 0x007F0200, 0xBF7F0200);
        renderHorizontalLine(context, z, x + 3 + width / 2, y + 19, x + 3 + width, y + 20, 0xBF7F0200, 0x007F0200);
    }

    private static void renderBorder(class_332 context, int x, int y, int width, int height, int z, int startColor, int endColor) {
        renderVerticalLine(context, x, y, height - 2, z, startColor, endColor);
        renderVerticalLine(context, x + width - 1, y, height - 2, z, startColor, endColor);
        renderHorizontalLine(context, x, y - 1, width, z, startColor);
        renderHorizontalLine(context, x, y - 1 + height - 1, width, z, endColor);
    }

    private static void renderVerticalLine(class_332 context, int x, int y, int height, int z, int color) {
        context.method_25294(x, y, x + 1, y + height, color);
    }

    private static void renderVerticalLine(class_332 context, int x, int y, int height, int z, int startColor, int endColor) {
        context.method_25296(x, y, x + 1, y + height, z, startColor);
    }

    private static void renderHorizontalLine(class_332 context, int x, int y, int width, int z, int color) {
        context.method_25294(x, y, x + width, y + 1, color);
    }

    private static void renderRectangle(class_332 context, int x, int y, int width, int height, int z, int color) {
        context.method_25294(x, y, x + width, y + height, color);
    }

    public static void renderHorizontalLine(class_332 context, int zLevel, int left, int top, int right, int bottom, int startColor, int endColor) {
        float endAlpha = (float) (endColor >> 24 & 255) / 255.0F;
        float endRed = (float) (endColor >> 16 & 255) / 255.0F;
        float endGreen = (float) (endColor >> 8 & 255) / 255.0F;
        float endBlue = (float) (endColor & 255) / 255.0F;
        float startAlpha = (float) (startColor >> 24 & 255) / 255.0F;
        float startRed = (float) (startColor >> 16 & 255) / 255.0F;
        float startGreen = (float) (startColor >> 8 & 255) / 255.0F;
        float startBlue = (float) (startColor & 255) / 255.0F;

//        RenderSystem.enableDepthTest();
//        RenderSystem.enableBlend();
//        RenderSystem.defaultBlendFunc();
//        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

//        VertexConsumer vertexConsumer = context.getVertexConsumers().getBuffer(RenderLayer.getGui());
//        Matrix4f matrix4f = context.getMatrices().peek().getPositionMatrix();
//
//        vertexConsumer.vertex(matrix4f, right, top, zLevel).color(endRed, endGreen, endBlue, endAlpha);
//        vertexConsumer.vertex(matrix4f, left, top, zLevel).color(startRed, startGreen, startBlue, startAlpha);
//        vertexConsumer.vertex(matrix4f, left, bottom, zLevel).color(startRed, startGreen, startBlue, startAlpha);
//        vertexConsumer.vertex(matrix4f, right, bottom, zLevel).color(endRed, endGreen, endBlue, endAlpha);
//        context.drawDeferredElements();
//        RenderSystem.disableScissorForRenderTypeDraws();
    }

}
