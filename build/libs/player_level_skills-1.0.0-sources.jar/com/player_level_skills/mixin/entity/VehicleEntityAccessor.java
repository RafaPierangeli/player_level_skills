package com.player_level_skills.mixin.entity;

import net.minecraft.class_1792;
import net.minecraft.class_8836;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_8836.class)
public interface VehicleEntityAccessor {

    @Invoker("asItem")
    class_1792 callAsItem();
}

