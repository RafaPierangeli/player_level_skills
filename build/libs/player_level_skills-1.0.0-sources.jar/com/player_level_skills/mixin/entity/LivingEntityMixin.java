package com.player_level_skills.mixin.entity;

import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.access.MobEntityAccess;
import com.player_level_skills.access.PlayerDropAccess;
import com.player_level_skills.entity.LevelExperienceOrbEntity;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.util.BonusHelper;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_8111;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {

    @Shadow
    protected int playerHitTimer;

    @Shadow
    @Nullable
    protected class_1657 attackingPlayer;

    public LivingEntityMixin(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @ModifyVariable(method = "modifyAppliedDamage", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/enchantment/EnchantmentHelper;getProtectionAmount(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/entity/damage/DamageSource;)F", shift = At.Shift.AFTER), ordinal = 1)
    private float modifyAppliedDamageMixin(float original, class_1282 source, float amount) {
        if (source.method_49708(class_8111.field_42345) && (Object) this instanceof class_1657 playerEntity) {
            return original + BonusHelper.fallDamageReductionBonus(playerEntity);
        } else {
            return original;
        }
    }

//    @ModifyVariable(method = "tryUseTotem", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/entity/LivingEntity;getStackInHand(Lnet/minecraft/util/Hand;)Lnet/minecraft/item/ItemStack;", ordinal = 0))
//    private ItemStack tryUseTotemMixin(ItemStack original) {
//        if ((Object) this instanceof PlayerEntity playerEntity && original.isOf(Items.TOTEM_OF_UNDYING)) {
//            if (playerEntity.isCreative()) {
//                return original;
//            }
//            LevelManager levelManager = ((LevelManagerAccess) playerEntity).getLevelManager();
//            if (!levelManager.hasRequiredItemLevel(original.getItem())) {
//                return ItemStack.EMPTY;
//            }
//        }
//        return original;
//    }
//
//    @Inject(method = "tryUseTotem", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/util/Hand;values()[Lnet/minecraft/util/Hand;"), cancellable = true)
//    private void tryUseTotemMixin(DamageSource source, CallbackInfoReturnable<Boolean> info) {
//        if ((Object) this instanceof PlayerEntity playerEntity && BonusHelper.deathGraceChanceBonus(playerEntity)) {
//            info.setReturnValue(true);
//        }
//    }

    @Inject(method = "drop", at = @At(value = "HEAD"), cancellable = true)
    protected void dropMixin(class_3218 world, class_1282 damageSource, CallbackInfo info) {
        if (!((Object) this instanceof class_1657) && attackingPlayer != null && this.playerHitTimer > 0 && ConfigInit.CONFIG.disableMobFarms
                && !((PlayerDropAccess) attackingPlayer).allowMobDrop()) {
            info.cancel();
        }
    }

    @Inject(method = "onDeath", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;drop(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/entity/damage/DamageSource;)V"))
    private void onDeathMixin(class_1282 source, CallbackInfo info) {
        if (attackingPlayer != null && this.playerHitTimer > 0 && ConfigInit.CONFIG.disableMobFarms) {
            ((PlayerDropAccess) attackingPlayer).increaseKilledMobStat(this.method_73183().method_22350(this.method_24515()));
        }
    }

    @Inject(method = "dropExperience", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/ExperienceOrbEntity;spawn(Lnet/minecraft/server/world/ServerWorld;Lnet/minecraft/util/math/Vec3d;I)V"))
    protected void dropExperience(CallbackInfo info) {
        if (ConfigInit.CONFIG.mobXPMultiplier > 0.0F) {
            if ((Object) this instanceof class_1308 mobEntity && ((MobEntityAccess) mobEntity).isSpawnerMob()) {
            } else {
                LevelExperienceOrbEntity.spawn((class_3218) this.method_73183(), this.method_73189(),
                        (int) (this.getExperienceToDrop() * ConfigInit.CONFIG.mobXPMultiplier
                                * (ConfigInit.CONFIG.dropXPbasedOnLvl && this.attackingPlayer != null
                                ? 1.0F + ConfigInit.CONFIG.basedOnMultiplier * ((LevelManagerAccess) this.attackingPlayer).getLevelManager().getOverallLevel()
                                : 1.0F)));
            }
        }
    }

    @Unique
    @Shadow
    protected int getExperienceToDrop() {
        return 0;
    }

}
