package com.player_level_skills.mixin.entity;

import com.player_level_skills.access.LevelManagerAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import com.player_level_skills.entity.LevelExperienceOrbEntity;
import net.minecraft.class_1299;
import net.minecraft.class_1683;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3857;
import com.player_level_skills.config.ConfigInit;

@Mixin(class_1683.class)
public abstract class ExperienceBottleEntityMixin extends class_3857 {

    public ExperienceBottleEntityMixin(class_1299<? extends class_3857> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(method = "onCollision", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/projectile/thrown/ExperienceBottleEntity;discard()V"), locals = LocalCapture.CAPTURE_FAILSOFT)
    protected void onCollisionMixin(class_239 hitResult, CallbackInfo info, int i) {
        if (ConfigInit.CONFIG.bottleXPMultiplier > 0.0F) {
            LevelExperienceOrbEntity.spawn((class_3218) this.method_73183(), this.method_73189().method_1031(0.0D, 0.5D, 0.0D),
                    (int) (i * ConfigInit.CONFIG.bottleXPMultiplier
                            * (ConfigInit.CONFIG.dropXPbasedOnLvl && this.method_24921() != null && this.method_24921() instanceof class_3222 serverPlayerEntity
                            ? 1.0F + ConfigInit.CONFIG.basedOnMultiplier * ((LevelManagerAccess) serverPlayerEntity).getLevelManager().getOverallLevel()
                            : 1.0F)));
        }
    }
}
