package com.player_level_skills.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.systems.RenderSystem;
import com.player_level_skills.screen.PlayerLevelSkillsScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_1703;
import net.minecraft.class_1723;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_465.class)
public abstract class HandledScreenMixin<T extends class_1703> extends class_437 {

    protected HandledScreenMixin(class_2561 title) { super(title); }


    @Shadow protected int x;
    @Shadow protected int y;
    @Shadow protected int backgroundWidth;
    @Shadow protected int backgroundHeight;
    @Shadow protected T handler;

    @Unique private static final class_2960 ATTRIBUTE_BOOK =
            class_2960.method_60655("attributescreen", "textures/gui/attribute_book.png");


    @Unique private int attributespanel$iconTick = 0;
    @Unique private PlayerLevelSkillsScreen player_level_skill$playerlevelSkillsScreen;

    @Unique
    private boolean attributespanel$shouldAttach() {
        return this.handler instanceof class_1723;
    }


    @Inject(method = "renderBackground", at = @At("TAIL"))
    private void attributespanel$onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!attributespanel$shouldAttach()) return;

        attributespanel$iconTick++;
        if (player_level_skill$playerlevelSkillsScreen != null) {
            player_level_skill$playerlevelSkillsScreen.method_25393();

            int iconSize = 9;
            int buttonX = this.x + this.backgroundWidth / 2 + (-61);
            int buttonY = this.y + 10;

            boolean hovered = mouseX >= buttonX && mouseX <= buttonX + iconSize &&
                    mouseY >= buttonY && mouseY <= buttonY + iconSize;

            int color = hovered ? 0xFFFFFFFF : 0xA9A9A9A9;


            boolean animate = true;
            if (hovered && animate) {
                float time = attributespanel$iconTick / 16f;
                float pulse = (float) Math.sin(time);
                float scale = 1.0f + 0.1f * pulse;



                context.method_51448().pushMatrix();
                context.method_51448().translate(buttonX + iconSize / 2f, buttonY + iconSize / 2f);
                context.method_51448().scale(scale, scale);
                context.method_51448().translate(-iconSize / 2f, -iconSize / 2f);
                context.method_25291(class_10799.field_56883,ATTRIBUTE_BOOK, 0, 0, 0, 0, iconSize, iconSize, 9, 9, color);
                context.method_51448().popMatrix();
            } else {
                context.method_25291(class_10799.field_56883,ATTRIBUTE_BOOK, buttonX, buttonY, 0, 0,iconSize,iconSize,9,9, color);
            }

            if (hovered) {
                context.method_51438(field_22793,class_2561.method_43471("attributepanel.tooltip.button"), mouseX, mouseY);
            }
        }
    }


    @Inject(method = "renderMain", at = @At("RETURN"))
    private void attributespanel$renderTooltipAfterEverything(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!attributespanel$shouldAttach()) return;
        if (player_level_skill$playerlevelSkillsScreen != null && player_level_skill$playerlevelSkillsScreen.isExpanded()) {
        //    player_level_skill$playerlevelSkillsScreen.renderTooltip(context);
        }
    }


    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void attributespanel$onMouseClick(class_11909 click, boolean bl, CallbackInfoReturnable<Boolean> cir) {
        if (!attributespanel$shouldAttach()) return;

        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();

        if (player_level_skill$playerlevelSkillsScreen != null) {
            int iconSize = 9;
            int buttonX = this.x + this.backgroundWidth / 2 + (-61);
            int buttonY = this.y + 10;

            // Verificação do clique no ícone do painel
            if (mouseX >= buttonX && mouseX <= buttonX + iconSize &&
                    mouseY >= buttonY && mouseY <= buttonY + iconSize) {
                player_level_skill$playerlevelSkillsScreen.toggle();
                cir.setReturnValue(true);
                cir.cancel();
                return;
            }

            // Lógica de interação com o painel aberto
            if (player_level_skill$playerlevelSkillsScreen.mouseClicked(mouseX, mouseY, button)) {

                this.method_25395(player_level_skill$playerlevelSkillsScreen);
                if (button == 0) {
                    this.method_25398(true);

                }
                cir.setReturnValue(true);
                cir.cancel();

            }
        }
    }
    // ===== INJECT: mouseDragged ✅ NOVO =====
    @Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true)
    private void attributespanel$onMouseDragged(class_11909 click, double offsetX, double offsetY, CallbackInfoReturnable<Boolean> cir) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();
        double deltaX = x;
        double deltaY = y;

        if (!attributespanel$shouldAttach()) return;

        if (player_level_skill$playerlevelSkillsScreen != null) {

            boolean handled = player_level_skill$playerlevelSkillsScreen.mouseDragged(mouseX, mouseY, button,
                    deltaX, deltaY);

            if (handled) {
                cir.setReturnValue(true);
                cir.cancel();
            }
        }
    }

    // ===== INJECT: mouseReleased ✅ NOVO =====
    @Inject(method = "mouseReleased", at = @At("HEAD"), cancellable = true)
    private void player_level_skill$onMouseReleased(class_11909 click, CallbackInfoReturnable<Boolean> cir) {
        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();

        if (!attributespanel$shouldAttach()) return;

        if (player_level_skill$playerlevelSkillsScreen != null) {
            boolean handled = player_level_skill$playerlevelSkillsScreen.mouseReleased(mouseX, mouseY, button);

            if (handled) {
                cir.setReturnValue(true);
                cir.cancel();
            }
        }
    }
}


