package com.player_level_skills.mixin;

import com.player_level_skills.Player_level_skills;
import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.screen.PlayerLevelSkillsScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1109;
import net.minecraft.class_11909;
import net.minecraft.class_124;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Mixin(class_465.class)
public abstract class HandledScreenInfoMixin<T extends class_1703> extends class_437 {

    @Shadow protected int x;
    @Shadow protected int y;
    @Shadow protected int backgroundWidth;
    @Shadow protected int backgroundHeight;
    @Shadow protected T handler;

    @Unique
    private static final class_2960 SKILL_ICON =
            class_2960.method_60655(Player_level_skills.MOD_ID, "textures/gui/skill_book.png");

    protected HandledScreenInfoMixin(class_2561 title) {
        super(title);
    }

    @Unique
    private boolean player_level_skills$shouldAttach() {
        return this.handler instanceof net.minecraft.class_1723;
    }

    @Inject(method = "renderBackground", at = @At("TAIL"))
    private void player_level_skills$drawBackground(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!player_level_skills$shouldAttach()) {
            return;
        }

        assert this.field_22787 != null;
        assert this.field_22787.field_1724 != null;

        LevelManager levelManager = ((LevelManagerAccess) this.field_22787.field_1724).getLevelManager();

        int iconSize = 9;
        int buttonX = this.x + this.backgroundWidth / 2 + ConfigInit.CONFIG.inventorySkillLevelPosX;
        int buttonY = this.y + ConfigInit.CONFIG.inventorySkillLevelPosY;
        int textX = (56 + ConfigInit.CONFIG.inventorySkillLevelPosX + this.x);
        int textY = (8 + ConfigInit.CONFIG.inventorySkillLevelPosY + this.y + field_22793.field_2000 / 2);

        boolean hovered = mouseX >= buttonX && mouseX <= buttonX + iconSize
                && mouseY >= buttonY && mouseY <= buttonY + iconSize;

        boolean hovereded = mouseX >= textX && mouseX <= textX + 14
                && mouseY >= (textY-3) && mouseY <= textY + 2;

        if (ConfigInit.CONFIG.inventorySkillLevel) {




            int color = 0xFFFFFFFF;
            if (levelManager.getSkillPoints() > 0) {
                color = 0xFF00E5FF;
            }

            context.method_51448().pushMatrix();
            context.method_51448().scale(0.6F, 0.6F);
            context.method_51448().translate(
                    (56 + ConfigInit.CONFIG.inventorySkillLevelPosX + this.x) / 0.6F,
                    (8 + ConfigInit.CONFIG.inventorySkillLevelPosY + this.y + field_22793.field_2000 / 2F) / 0.6F);
            context.method_51439(this.field_22793, class_2561.method_43469("text.levelz.gui.short_level", levelManager.getOverallLevel()), 0, -field_22793.field_2000 / 2, color, false);
            context.method_51448().popMatrix();
            if (hovereded) {
                context.method_51438(this.field_22793, class_2561.method_43469("key.player_level_skills.open_screen", levelManager.getOverallLevel()).method_27692(class_124.field_1075), mouseX, mouseY);
            }
        }
// Icone pré preparado
//        int color = hovered ? 0xFFFFFFFF : 0xA9A9A9A9;
//
//        context.drawTexture(RenderPipelines.GUI_TEXTURED, SKILL_ICON, buttonX, buttonY, 0, 0, iconSize, iconSize, 9, 9, color);
//
//        if (hovered) {
//            int color2 = 0xFFFFFFFF;
//            if (levelManager.getSkillPoints() > 0) {
//                color2 = 0xFF55FF55;
//            }
//            context.drawTooltip(this.textRenderer, Text.translatable("key.player_level_skills.open_screen", levelManager.getOverallLevel()).formatted(Formatting.RED), mouseX, mouseY);
//        }
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void player_level_skills$onMouseClicked(class_11909 click, boolean bl, CallbackInfoReturnable<Boolean> cir) {
        if (!player_level_skills$shouldAttach()) {
            return;
        }

        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();
        int button = click.method_74245();

        int iconSize = 9;
        int buttonX = this.x + this.backgroundWidth / 2 + ConfigInit.CONFIG.inventorySkillLevelPosX;
        int buttonY = this.y + ConfigInit.CONFIG.inventorySkillLevelPosY;
        int textX = (56 + ConfigInit.CONFIG.inventorySkillLevelPosX + this.x);
        int textY = (8 + ConfigInit.CONFIG.inventorySkillLevelPosY + this.y + field_22793.field_2000 / 2);

        if (mouseX >= textX && mouseX <= textX + 14
                && mouseY >= (textY-3) && mouseY <= textY + 2) {

            assert this.field_22787 != null;

            this.field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
            this.field_22787.method_1507(null);

            this.field_22787.execute(() -> {
                class_310 client = class_310.method_1551();
                if (client.field_1724 != null) {
                    client.method_1507(new PlayerLevelSkillsScreen());
                }
            });

            cir.setReturnValue(true);
            cir.cancel();
        }
    }

    @Inject(method = "mouseReleased", at = @At("HEAD"), cancellable = true)
    private void player_level_skills$onMouseReleased(class_11909 click, CallbackInfoReturnable<Boolean> cir) {
        if (!player_level_skills$shouldAttach()) {
            return;
        }
    }

    @Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true)
    private void player_level_skills$onMouseDragged(class_11909 click, double offsetX, double offsetY, CallbackInfoReturnable<Boolean> cir) {
        if (!player_level_skills$shouldAttach()) {
            return;
        }
    }
}