package com.player_level_skills.mixin;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1297.class)
public interface EntityAccessor {

    @Invoker("canAddPassenger")
    boolean callCanAddPassenger(class_1297 passenger);

}

