package com.player_level_skills.mixin.block;

import com.player_level_skills.util.BonusHelper;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_2261.class)
public abstract class PlantBlockMixin extends class_2248 {

    public PlantBlockMixin(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        if (!world.method_8608() && player != null && !player.method_68878()) {
            BonusHelper.plantDropChanceBonus(player, state, pos);
        }
        return super.method_9576(world, pos, state, player);
    }

}

