package com.player_level_skills.mixin.network;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_2535;
import net.minecraft.class_2600;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import com.player_level_skills.access.OrbAccess;
import com.player_level_skills.entity.LevelExperienceOrbEntity;
import com.player_level_skills.network.packet.OrbPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

@Environment(EnvType.CLIENT)
@Mixin(class_634.class)
public abstract class ClientPlayNetworkHandlerMixin extends class_8673 implements OrbAccess {

    @Shadow
    @Mutable
    private class_638 world;

    public ClientPlayNetworkHandlerMixin(class_310 client, class_2535 connection, class_8675 connectionState) {
        super(client, connection, connectionState);
    }

    @Override
    public void onLevelExperienceOrbSpawn(OrbPacket packet) {
        class_2600.method_11074(packet, (class_634) (Object) this, this.field_45588.method_74186());
        double d = packet.getX();
        double e = packet.getY();
        double f = packet.getZ();
        class_1297 entity = new LevelExperienceOrbEntity(this.world, d, e, f, packet.getExperience());
        entity.method_43391(d, e, f);
        entity.method_36456(0.0F);
        entity.method_36457(0.0F);
        entity.method_5838(packet.getEntityId());
        this.world.method_53875(entity);
    }
}
