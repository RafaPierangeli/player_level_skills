package com.player_level_skills.mixin.item;

import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.level.LevelManager;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1792.class)
public class SwordItemMixin {

    @Inject(method = "postHit", at = @At("HEAD"), cancellable = true)
    private void postHitMixin(class_1799 stack, class_1309 target, class_1309 attacker, CallbackInfo ci) {
        if (!(attacker instanceof class_1657 playerEntity)) {
            return;
        }

        if (playerEntity.method_68878()) {
            return;
        }

        LevelManager levelManager = ((LevelManagerAccess) playerEntity).getLevelManager();

        if (!levelManager.hasRequiredItemLevel(stack.method_7909())) {
            ci.cancel();
        }
    }

    @Inject(method = "postDamageEntity", at = @At("HEAD"), cancellable = true)
    private void postDamageEntityMixin(class_1799 stack, class_1309 target, class_1309 attacker, CallbackInfo ci) {
        if (!(attacker instanceof class_1657 playerEntity)) {
            return;
        }

        if (playerEntity.method_68878()) {
            return;
        }

        LevelManager levelManager = ((LevelManagerAccess) playerEntity).getLevelManager();

        if (!levelManager.hasRequiredItemLevel(stack.method_7909())) {
            ci.cancel();
        }
    }
}