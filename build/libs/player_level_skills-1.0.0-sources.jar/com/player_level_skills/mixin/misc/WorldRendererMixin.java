package com.player_level_skills.mixin.misc;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_12074;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_638;
import net.minecraft.class_761;
import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.config.ConfigInit;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_761.class)
public abstract class WorldRendererMixin {

    @Shadow
    @Mutable
    @Final
    private class_310 client;

    @Nullable
    @Shadow
    private class_638 world;

    @Inject(method = "drawBlockOutline", at = @At(value = "HEAD"), cancellable = true)
    private void drawBlockOutlineMixin(class_4587 matrices, class_4588 vertexConsumer, double x, double y, double z, class_12074 state, int color, float lineWidth, CallbackInfo ci) {
//        if (ConfigInit.CONFIG.highlightLocked && !((LevelManagerAccess) client.player).getLevelManager().hasRequiredMiningLevel(blockState.getBlock())) {
//            WorldRenderer.drawShapeOutline(matrices, vertexConsumer, blockState.getOutlineShape(this.world, blockPos, ShapeContext.of(entity)), (double) blockPos.getX() - cameraX,
//                    (double) blockPos.getY() - cameraY, (double) blockPos.getZ() - cameraZ, 1.0F, 0.0F, 0.0F, 0.4F, false);
//            info.cancel();
//        }
    }
}

