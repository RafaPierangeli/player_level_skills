package com.player_level_skills.mixin.misc;

import com.player_level_skills.util.RestrictionHelper;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1703.class)
public class ScreenHandlerMixin {
    @Shadow
    private class_1799 cursorStack;

    @Shadow
    @Final
    @Mutable
    public class_2371<class_1735> slots = class_2371.method_10211();

    @Inject(method = "internalOnSlotClick", at = @At("HEAD"), cancellable = true)
    private void internalOnSlotClickMixin(int slotIndex, int button, class_1713 actionType, class_1657 player, CallbackInfo info) {
        if (player.method_68878()) {
            return;
        }
        if (slotIndex >= 0 && slotIndex != class_1703.field_30730 && RestrictionHelper.restrictSlotClick(player, actionType, this.cursorStack, this.slots.get(slotIndex), (class_1703) (Object) this)) {
            info.cancel();
        }
    }

}
