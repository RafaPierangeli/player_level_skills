package com.player_level_skills.mixin.misc;

import java.util.Iterator;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2703;
import net.minecraft.class_634;
import net.minecraft.class_640;
import com.player_level_skills.access.ClientPlayerListAccess;

@SuppressWarnings("rawtypes")
@Environment(EnvType.CLIENT)
@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {

    @Inject(method = "onPlayerList", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/SocialInteractionsManager;setPlayerOnline(Lnet/minecraft/client/network/PlayerListEntry;)V"), locals = LocalCapture.CAPTURE_FAILSOFT)
    private void onPlayerListMixin(class_2703 packet, CallbackInfo info, Iterator var2, class_2703.class_2705 entry, class_640 playerListEntry) {
        ((ClientPlayerListAccess) playerListEntry).setLevel(((ClientPlayerListAccess) packet).getLevelMap().get(playerListEntry.method_2966().id()));
    }

    @Inject(method = "onPlayerList", at = @At(value = "INVOKE", target = "Ljava/util/EnumSet;iterator()Ljava/util/Iterator;"), locals = LocalCapture.CAPTURE_FAILSOFT)
    private void onPlayerListGameModeMixin(class_2703 packet, CallbackInfo info, Iterator var2, class_2703.class_2705 entry, class_640 playerListEntry) {
        if (packet.method_46327().contains(class_2703.class_5893.field_29137)) {
            ((ClientPlayerListAccess) playerListEntry).setLevel(((ClientPlayerListAccess) packet).getLevelMap().get(playerListEntry.method_2966().id()));
        }
    }

}
