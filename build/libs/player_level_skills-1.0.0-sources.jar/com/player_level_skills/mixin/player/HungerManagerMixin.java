package com.player_level_skills.mixin.player;

import com.player_level_skills.util.BonusHelper;
import net.minecraft.class_1702;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1702.class)
public class HungerManagerMixin {

//    @Inject(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;heal(F)V", ordinal = 1))
//    private void updateStaminaMixin(ServerPlayerEntity player, CallbackInfo ci) {
//        BonusHelper.healthRegenBonus(player);
//    }

    @Inject(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/HungerManager;addExhaustion(F)V", shift = Shift.AFTER, ordinal = 0))
    private void updateAbsorptionMixin(class_3222 player, CallbackInfo ci) {
        BonusHelper.healthAbsorptionBonus(player);
    }
}