package com.player_level_skills.mixin.player;

import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2703;
import net.minecraft.class_3222;
import net.minecraft.class_9129;
import com.player_level_skills.access.LevelManagerAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.player_level_skills.access.ClientPlayerListAccess;

@Mixin(class_2703.class)
public abstract class ClientPlayerListS2CPacketMixin implements ClientPlayerListAccess {

    @Unique
    private Map<UUID, Integer> levelMap = new HashMap<UUID, Integer>();

    @Inject(method = "Lnet/minecraft/network/packet/s2c/play/PlayerListS2CPacket;<init>(Ljava/util/EnumSet;Ljava/util/Collection;)V", at = @At("TAIL"))
    public void playerListS2CPacketMixin(EnumSet<class_2703.class_5893> actions, Collection<class_3222> players, CallbackInfo info) {
        players.forEach((player) -> {
            this.levelMap.put(player.method_5667(), ((LevelManagerAccess) player).getLevelManager().getOverallLevel());
        });
    }

    @Inject(method = "Lnet/minecraft/network/packet/s2c/play/PlayerListS2CPacket;<init>(Lnet/minecraft/network/packet/s2c/play/PlayerListS2CPacket$Action;Lnet/minecraft/server/network/ServerPlayerEntity;)V", at = @At("TAIL"))
    public void playerListS2CPacketMixin(class_2703.class_5893 action, class_3222 player, CallbackInfo info) {
        this.levelMap.put(player.method_5667(), ((LevelManagerAccess) player).getLevelManager().getOverallLevel());
    }

    @Inject(method = "<init>(Lnet/minecraft/network/RegistryByteBuf;)V", at = @At("TAIL"))
    public void playerListS2CPacketMixin(class_9129 buf, CallbackInfo info) {
        this.levelMap = buf.method_34067((bufx -> bufx.method_10790()), class_2540::readInt);
    }

    @Inject(method = "write", at = @At("TAIL"))
    private void writeMixin(class_9129 buf, CallbackInfo info) {
        buf.method_34063(this.levelMap, ((bufx, value) -> bufx.method_10797(value)), class_2540::method_53002);
    }

    @Override
    public Map<UUID, Integer> getLevelMap() {
        return this.levelMap;
    }

}
