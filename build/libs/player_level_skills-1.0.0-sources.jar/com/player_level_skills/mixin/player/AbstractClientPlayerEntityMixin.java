package com.player_level_skills.mixin.player;

import com.player_level_skills.access.ClientPlayerAccess;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_640;
import net.minecraft.class_742;
import com.player_level_skills.access.ClientPlayerListAccess;
import org.spongepowered.asm.mixin.Unique;

@Environment(EnvType.CLIENT)
@Mixin(class_742.class)
public abstract class AbstractClientPlayerEntityMixin implements ClientPlayerListAccess, ClientPlayerAccess {

    @Unique
    private boolean shouldRenderClientName = true;

    @Shadow
    @Nullable
    protected class_640 getPlayerListEntry() {
        return null;
    }

    @Override
    public int getLevel() {
        if (getPlayerListEntry() != null) {
            return ((ClientPlayerListAccess) getPlayerListEntry()).getLevel();
        }
        return 0;
    }

    @Override
    public boolean shouldRenderClientName() {
        return this.shouldRenderClientName;
    }

    @Override
    public void setShouldRenderClientName(boolean shouldRenderClientName) {
        this.shouldRenderClientName = shouldRenderClientName;
    }
}
