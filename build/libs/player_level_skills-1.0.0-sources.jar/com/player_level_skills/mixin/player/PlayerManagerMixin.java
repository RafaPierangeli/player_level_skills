package com.player_level_skills.mixin.player;

import com.mojang.authlib.GameProfile;
import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.util.PacketHelper;
import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_8792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3324.class)
public class PlayerManagerMixin {

    @Inject(
            method = "onPlayerConnect",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/server/PlayerManager;sendStatusEffects(Lnet/minecraft/server/network/ServerPlayerEntity;)V")
    )
    private void onPlayerConnectMixin(class_2535 connection, class_3222 player, class_8792 clientData, CallbackInfo ci) {
        LevelManager levelManager = ((LevelManagerAccess) player).getLevelManager();

        if (levelManager.getSkillPoints() <= 0 && ConfigInit.CONFIG.startPoints > 0) {
            levelManager.setSkillPoints(ConfigInit.CONFIG.startPoints);
            PacketHelper.updateLevels(player);
        }
    }
}