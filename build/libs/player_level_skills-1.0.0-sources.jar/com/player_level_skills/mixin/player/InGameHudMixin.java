package com.player_level_skills.mixin.player;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_329;
import com.player_level_skills.access.LevelManagerAccess;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Environment(EnvType.CLIENT)
@Mixin(class_329.class)
public class InGameHudMixin {

    @Shadow
    @Mutable
    @Final
    private class_310 client;

    @ModifyConstant(method = "shouldShowExperienceBar", constant = @Constant(intValue = 8453920), require = 0)
    private int modifyExperienceNumberColor(int original) {
        assert client.field_1724 != null;
        if (((LevelManagerAccess) client.field_1724).getLevelManager().hasAvailableLevel()) {
            return 1507303;
        } else {
            return original;
        }
    }

}
