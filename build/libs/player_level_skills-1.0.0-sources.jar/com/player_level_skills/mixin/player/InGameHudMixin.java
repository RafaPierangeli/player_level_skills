package com.player_level_skills.mixin.player;

import com.player_level_skills.access.LevelManagerAccess;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11223;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_11223.class)
public interface InGameHudMixin {

    @Inject(method = "drawExperienceLevel", at = @At("HEAD"), cancellable = true)
    private static void player_level_skills$drawExperienceLevel(class_332 context, class_327 textRenderer, int level, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return;
        }

        int color = 0xFF55FF55;
        if (((LevelManagerAccess) client.field_1724).getLevelManager().hasAvailableLevel()) {
            color = 0xFF00E5FF;
        }

        class_2561 text = class_2561.method_43470(Integer.toString(level));

        // posição vanilla aproximada: precisa ajustar se quiser pixel-perfect
        int x = context.method_51421() / 2 - textRenderer.method_27525(text) / 2;
        int y = context.method_51443() - 36;

        context.method_51439(textRenderer, text, x, y, color, true);
        ci.cancel();
    }
}