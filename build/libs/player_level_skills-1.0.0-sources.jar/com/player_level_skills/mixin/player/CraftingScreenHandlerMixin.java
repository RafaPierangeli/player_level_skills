package com.player_level_skills.mixin.player;

import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.level.LevelManager;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1714;
import net.minecraft.class_1731;
import net.minecraft.class_1799;
import net.minecraft.class_2653;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3955;
import net.minecraft.class_8566;
import net.minecraft.class_8786;
import net.minecraft.class_9694;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_1714.class)
public class CraftingScreenHandlerMixin {

    @Inject(method = "updateResult", at = @At(value = "INVOKE", target = "Lnet/minecraft/inventory/CraftingResultInventory;setStack(ILnet/minecraft/item/ItemStack;)V"), locals = LocalCapture.CAPTURE_FAILSOFT, cancellable = true)
    private static void updateResultMixin(class_1703 handler, class_3218 world, class_1657 player, class_8566 craftingInventory, class_1731 resultInventory, @org.jspecify.annotations.Nullable class_8786<class_3955> recipe, CallbackInfo ci, class_9694 craftingRecipeInput, class_3222 serverPlayerEntity, class_1799 itemStack) {
        if (player.method_68878()) {
            return;
        }
        LevelManager levelManager = ((LevelManagerAccess) player).getLevelManager();
        if (!levelManager.hasRequiredCraftingLevel(itemStack.method_7909())) {
            resultInventory.method_5447(0, class_1799.field_8037);
            handler.method_34245(0, class_1799.field_8037);
            serverPlayerEntity.field_13987.method_14364(new class_2653(handler.field_7763, handler.method_37422(), 0, class_1799.field_8037));
            ci.cancel();
        }
    }

}
