package com.player_level_skills.mixin.player;

import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.access.PlayerDropAccess;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.entity.LevelExperienceOrbEntity;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.util.BonusHelper;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2791;
import net.minecraft.class_3218;
import net.minecraft.class_8103;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin extends class_1309 implements LevelManagerAccess, PlayerDropAccess {

    private final class_1657 playerEntity = (class_1657) (Object) this;
    @Unique
    private final LevelManager levelManager = new LevelManager(playerEntity);

    @Unique
    private int killedMobsInChunk;
    @Unique
    @Nullable
    private class_2791 killedMobChunk;

    public PlayerEntityMixin(class_1299<? extends class_1309> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(method = "readCustomData", at = @At(value = "TAIL"))
    public void readCustomData(class_11368 view, CallbackInfo info) {
        this.levelManager.readNbt(view);
    }

    @Inject(method = "writeCustomData", at = @At(value = "TAIL"))
    public void writeCustomData(class_11372 view, CallbackInfo info) {
        this.levelManager.writeNbt(view);
    }

    @ModifyVariable(method = "addExhaustion", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/HungerManager;addExhaustion(F)V"), ordinal = 0, argsOnly = true)
    private float addExhaustionMixin(float original) {
        original *= BonusHelper.exhaustionReductionBonus(this.playerEntity);
        return original;
    }

    @ModifyVariable(method = "attack", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/item/Item;getBonusAttackDamage(Lnet/minecraft/entity/Entity;FLnet/minecraft/entity/damage/DamageSource;)F"), ordinal = 0)
    private boolean attackKnockbackkMixin(boolean original) {
        if (!original && BonusHelper.meleeKnockbackAttackChanceBonus(this.playerEntity)) {
            return true;
        }
        return original;
    }

    @ModifyVariable(method = "attack", at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/item/Item;getBonusAttackDamage(Lnet/minecraft/entity/Entity;FLnet/minecraft/entity/damage/DamageSource;)F"), ordinal = 1)
    private boolean attackCriticalMixin(boolean original) {
        if (!original && BonusHelper.meleeCriticalAttackChanceBonus(this.playerEntity)) {
            return true;
        }
        return original;
    }

    @ModifyVariable(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;getWeaponStack()Lnet/minecraft/item/ItemStack;"), ordinal = 0)
    private float attackMixin(float original) {
        if (this.playerEntity.method_68878()) {
            return original;
        }
        if (!levelManager.hasRequiredItemLevel(method_59958().method_7909())) {
            return 0.0f;
        }
        return original;
    }

    //@ModifyVariable(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;playSound(Lnet/minecraft/entity/player/PlayerEntity;DDDLnet/minecraft/sound/SoundEvent;Lnet/minecraft/sound/SoundCategory;FF)V", ordinal = 0), ordinal = 0)
    //private float attackCriticalDamageMixin(float original) {
    //    original += BonusHelper.meleeCriticalDamageBonus(this.playerEntity);
    //    return original;
    //}

    @ModifyVariable(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getVelocity()Lnet/minecraft/util/math/Vec3d;"), ordinal = 3)
    private float attackDoubleDamageMixin(float original) {
        if (BonusHelper.meleeDoubleDamageBonus(this.playerEntity)) {
            original *= 2f;
        }
        return original;
    }

    @Inject(method = "damage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;dropShoulderEntities()V"), cancellable = true)
    private void damageMixin(class_3218 world, class_1282 source, float amount, CallbackInfoReturnable<Boolean> cir) {
        BonusHelper.damageReflectionBonus(this.playerEntity, source, amount);
        if (!source.method_48789(class_8103.field_42242) && BonusHelper.evadingDamageBonus(this.playerEntity)) {
            cir.setReturnValue(false);
        }
    }

    //@Inject(method = "eatFood", at = @At(value = "HEAD"))
    //private void eatFoodMixin(World world, ItemStack stack, FoodComponent foodComponent, CallbackInfoReturnable<ItemStack> info) {
    //    BonusHelper.foodIncreasionBonus(this.playerEntity, stack);
    //}

    @Shadow
    public abstract class_1799 method_59958();


    @Override
    public LevelManager getLevelManager() {
        return this.levelManager;
    }

    @Override
    public void increaseKilledMobStat(class_2791 chunk) {
        if (killedMobChunk != null && killedMobChunk == chunk) {
            killedMobsInChunk++;
        } else {
            killedMobChunk = chunk;
            killedMobsInChunk = 0;
        }
    }

    @Override
    public void resetKilledMobStat() {
        killedMobsInChunk = 0;
    }

    @Override
    public boolean allowMobDrop() {
        return killedMobsInChunk < ConfigInit.CONFIG.mobKillCount;
    }


//    @Override
//    protected void dropExperience(ServerWorld serverWorld, @Nullable Entity attacker) {
//        System.out.println("dropExperience entrou: " + this.getType());
//
//        if (this.shouldDropExperience()) {
//            System.out.println("shouldDropXp = true");
//        } else {
//            System.out.println("shouldDropXp = false");
//        }
//
//        System.out.println("resetCurrentXp = " + ConfigInit.CONFIG.resetCurrentXp);
//
//        int xp = (int) (this.levelManager.getLevelProgress() * this.levelManager.getNextLevelExperience());
//        System.out.println("xp calculado = " + xp);
//
//        if (xp > 0) {
//            LevelExperienceOrbEntity.spawn(serverWorld, this.getEntityPos(), xp);
//            System.out.println("orb custom spawnada");
//        } else {
//            System.out.println("xp zerado");
//        }
//
//        super.dropExperience(serverWorld, attacker);
//    }

    @Override
    protected void method_23883(class_3218 world, @Nullable class_1297 attacker) {
        if (this.method_6054()
                && world.method_64395().method_76185(class_1928.field_19391)
                && ConfigInit.CONFIG.resetCurrentXp) {

            int xp = (int) (this.levelManager.getLevelProgress() * this.levelManager.getNextLevelExperience());

            if (xp > 0) {
                LevelExperienceOrbEntity.spawn(world, this.method_73189(), 50);
            }
        }

        super.method_23883(world, attacker);
    }







//    @Override
//    protected void dropExperience(@Nullable Entity attacker) {
//        if (this.playerEntity.getEntityWorld() instanceof ServerWorld serverWorld && this.shouldDropExperience() && this.getEntityWorld().getGameRules().getBoolean(GameRules.DO_MOB_LOOT) && ConfigInit.CONFIG.resetCurrentXp) {
//            LevelExperienceOrbEntity.spawn(serverWorld, this.getEntityPos(), (int) (this.levelManager.getLevelProgress() * this.levelManager.getNextLevelExperience()));
//        }
//        super.getExperienceToDrop(attacker);
//    }

//
//@Override
//protected void dropExperience(ServerWorld serverWorld, @Nullable Entity attacker) {
//    System.out.println("dropExperience chamado: " + this.getType());
//    if (this.shouldDropExperience() && serverWorld.getGameRules().getValue(GameRules.DO_MOB_LOOT) && ConfigInit.CONFIG.resetCurrentXp) {
//            LevelExperienceOrbEntity.spawn(serverWorld, this.getEntityPos(), (int) (this.levelManager.getLevelProgress() * this.levelManager.getNextLevelExperience()));
//        System.out.println("orb custom spawnada");
//        }
//        super.getExperienceToDrop(serverWorld,attacker);
//    }

//    @Override
//    protected void dropXp(@Nullable Entity attacker) {
//        if (this.playerEntity.getEntityWorld() instanceof ServerWorld serverWorld
//                && this.shouldDropExperience()
//                && serverWorld.getGameRules().getValue(GameRules.DO_MOB_LOOT)
//                && ConfigInit.CONFIG.resetCurrentXp) {
//
//            int xp = (int) (this.levelManager.getLevelProgress() * this.levelManager.getNextLevelExperience());
//
//            if (xp > 0) {
//                LevelExperienceOrbEntity.spawn(serverWorld, this.getEntityPos(), xp);
//            }
//        }
//
//        super.dropXp(attacker);
//    }

}