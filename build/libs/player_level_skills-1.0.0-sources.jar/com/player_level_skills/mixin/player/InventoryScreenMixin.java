package com.player_level_skills.mixin.player;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1661;
import net.minecraft.class_1723;
import net.minecraft.class_2561;
import net.minecraft.class_490;
import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.level.LevelManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_490.class)
public abstract class InventoryScreenMixin {

    public InventoryScreenMixin(class_1723 screenHandler, class_1661 playerInventory, class_2561 text) {
        super();
    }

//    @Inject(method = "drawBackground", at = @At("TAIL"))
//    protected void drawBackgroundMixin(DrawContext context, float delta, int mouseX, int mouseY, CallbackInfo info) {
//        assert this.client != null;
//        assert this.client.player != null;
//        if (ConfigInit.CONFIG.inventorySkillLevel) {
//            LevelManager levelManager = (((LevelManagerAccess) this.client.player).getLevelManager());
//            // 0xAARRGGBB Format
//            int color = 0xFFFFFFFF;
//            if (levelManager.getSkillPoints() > 0) {
//                color = 1507303;
//            }
//
//            context.getMatrices().pushMatrix();
//            context.getMatrices().scale(0.6F, 0.6F);
//            context.getMatrices().translate((28 + ConfigInit.CONFIG.inventorySkillLevelPosX + this.x) / 0.6F,
//                    (8 + ConfigInit.CONFIG.inventorySkillLevelPosY + this.y + textRenderer.fontHeight / 2F) / 0.6F);
//            context.drawText(this.textRenderer, Text.translatable("text.levelz.gui.short_level", levelManager.getOverallLevel()), 0, -textRenderer.fontHeight / 2, color, false);
//            context.getMatrices().popMatrix();
//        }
//    }
}

