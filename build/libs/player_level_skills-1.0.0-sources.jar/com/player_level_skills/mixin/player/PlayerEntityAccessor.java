package com.player_level_skills.mixin.player;

import net.minecraft.class_11890;
import net.minecraft.class_2940;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_11890.class)
public interface PlayerEntityAccessor {

    @Accessor("PLAYER_MODE_CUSTOMIZATION_ID")
    static class_2940<Byte> getPLAYER_MODEL_PARTS() {
        throw new AssertionError();
    }

}

