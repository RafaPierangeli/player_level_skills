package com.player_level_skills.mixin.player;

import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1657.class)
public interface PlayerEntityAccessor {

//    @Accessor("PLAYER_MODEL_PARTS")
//    static TrackedData<Byte> getPLAYER_MODEL_PARTS() {
//        throw new AssertionError();
//    }

}

