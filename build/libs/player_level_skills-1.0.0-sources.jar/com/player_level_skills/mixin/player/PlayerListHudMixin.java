package com.player_level_skills.mixin.player;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_355;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import com.player_level_skills.access.ClientPlayerListAccess;
import com.player_level_skills.config.ConfigInit;

@Environment(EnvType.CLIENT)
@Mixin(class_355.class)
public class PlayerListHudMixin {

    @Inject(method = "getPlayerName", at = @At(value = "RETURN", ordinal = 1), cancellable = true)
    private void getPlayerNameMixin(class_640 entry, CallbackInfoReturnable<class_2561> info) {
        if (ConfigInit.CONFIG.showLevelList)
            info.setReturnValue(this.applyGameModeFormatting(entry,
                    class_268.method_1142(entry.method_2955(), class_2561.method_43469("text.levelz.scoreboard", ((ClientPlayerListAccess) entry).getLevel(), entry.method_2966().name()))));
    }

    @Shadow
    private class_2561 applyGameModeFormatting(class_640 entry, class_5250 name) {
        return null;
    }

}
