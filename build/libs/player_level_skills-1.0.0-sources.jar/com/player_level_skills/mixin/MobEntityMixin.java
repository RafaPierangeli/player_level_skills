package com.player_level_skills.mixin;

import com.player_level_skills.access.MobEntityAccess;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1308;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1308.class)
public abstract class MobEntityMixin implements MobEntityAccess {

    @Unique
    private boolean spawnerMob = false;

    @Inject(method = "readCustomData", at = @At("TAIL"))
    private void readCustomData(class_11368 view, CallbackInfo info) {
        this.spawnerMob = view.method_71433("SpawnerMob",false);
    }

    @Inject(method = "writeCustomData", at = @At("TAIL"))
    private void writeCustomData(class_11372 view, CallbackInfo info) {
        view.method_71472("SpawnerMob", this.spawnerMob);
    }

    @Override
    public void setSpawnerMob(boolean spawnerMob) {
        this.spawnerMob = spawnerMob;
    }

    @Override
    public boolean isSpawnerMob() {
        return this.spawnerMob;
    }
}