package com.player_level_skills.data;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.player_level_skills.Player_level_skills;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.level.Skill;
import com.player_level_skills.level.restriction.PlayerRestriction;
import com.player_level_skills.registry.EnchantmentRegistry;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.*;

public record VRestrictionLoader(class_7225.class_7874 wrapperLookup) implements SimpleSynchronousResourceReloadListener {

    public static final class_2960 ID = Player_level_skills.identifierOf("restriction");

    private static final Logger LOGGER = LogManager.getLogger("LevelZ");

    private static final List<Integer> blockList = new ArrayList<>();
    private static final List<Integer> craftingList = new ArrayList<>();
    private static final List<Integer> entityList = new ArrayList<>();
    private static final List<Integer> itemList = new ArrayList<>();
    private static final List<Integer> miningList = new ArrayList<>();
    private static final List<Integer> enchantmentList = new ArrayList<>();

//    private ItemStringReader itemStringReader = new ItemStringReader(BuiltinRegistries.createWrapperLookup());

    @Override
    public class_2960 getFabricId() {
        return ID;
    }

    @Override
    public void method_14491(class_3300 manager) {


        LevelManager.BLOCK_RESTRICTIONS.clear();
        LevelManager.CRAFTING_RESTRICTIONS.clear();
        LevelManager.ENTITY_RESTRICTIONS.clear();
        LevelManager.ITEM_RESTRICTIONS.clear();
        LevelManager.MINING_RESTRICTIONS.clear();
        LevelManager.ENCHANTMENT_RESTRICTIONS.clear();

        if (!ConfigInit.CONFIG.restrictions) {
            return;
        }
        EnchantmentRegistry.updateEnchantments(this.wrapperLookup());

        manager.method_14488("restriction", id -> id.method_12832().endsWith(".json")).forEach((id, resourceRef) -> {
            try {
                if (!ConfigInit.CONFIG.defaultRestrictions && id.method_12832().endsWith("/default.json")) {
                    return;
                }
                LOGGER.info("C - skills map size = {}", LevelManager.SKILLS.size());
                InputStream stream = resourceRef.method_14482();
                JsonObject data = JsonParser.parseReader(new InputStreamReader(stream)).getAsJsonObject();

                Map<String, Integer> skillKeyIdMap = new HashMap<>();
                for (Skill skill : LevelManager.SKILLS.values()) {
                    skillKeyIdMap.put(skill.getKey(), skill.getId());

                }

                for (String mapKey : data.keySet()) {
                    JsonObject restrictionJsonObject = data.getAsJsonObject(mapKey);
                    Map<Integer, Integer> skillLevelRestrictions = new HashMap<>();
                    boolean replace = restrictionJsonObject.has("replace") && restrictionJsonObject.get("replace").getAsBoolean();

                    JsonObject skillRestrictions = restrictionJsonObject.getAsJsonObject("skills");
                    for (String skillKey : skillRestrictions.keySet()) {
                        if (skillKeyIdMap.containsKey(skillKey)) {
                            skillLevelRestrictions.put(skillKeyIdMap.get(skillKey), skillRestrictions.get(skillKey).getAsInt());
                        } else {
                            LOGGER.warn("01 Restriction {} contains an unrecognized skill called {}.", mapKey, skillKey);
                        }
                    }

                    if (!skillLevelRestrictions.isEmpty()) {
                        // blocks
                        if (restrictionJsonObject.has("blocks")) {
                            for (JsonElement blockElement : restrictionJsonObject.getAsJsonArray("blocks")) {
                                class_2960 blockIdentifier = class_2960.method_60654(blockElement.getAsString());
                                if (class_7923.field_41175.method_10250(blockIdentifier)) {
                                    int blockRawId = class_7923.field_41175.method_10206(class_7923.field_41175.method_63535(blockIdentifier));

                                    if (blockList.contains(blockRawId)) {
                                        continue;
                                    }
                                    if (replace) {
                                        blockList.add(blockRawId);
                                    }
                                    LevelManager.BLOCK_RESTRICTIONS.put(blockRawId, new PlayerRestriction(blockRawId, skillLevelRestrictions));
                                } else {
                                    LOGGER.warn("02 Restriction {} contains an unrecognized block id called {}.", mapKey, blockIdentifier);
                                }
                            }
                        }
                        // crafting
                        if (restrictionJsonObject.has("crafting")) {
                            for (JsonElement craftingElement : restrictionJsonObject.getAsJsonArray("crafting")) {
                                class_2960 craftingIdentifier = class_2960.method_60654(craftingElement.getAsString());
                                if (class_7923.field_41178.method_10250(craftingIdentifier)) {
                                    int craftingRawId = class_7923.field_41178.method_10206(class_7923.field_41178.method_63535(craftingIdentifier));

                                    if (craftingList.contains(craftingRawId)) {
                                        continue;
                                    }
                                    if (replace) {
                                        craftingList.add(craftingRawId);
                                    }
                                    LevelManager.CRAFTING_RESTRICTIONS.put(craftingRawId, new PlayerRestriction(craftingRawId, skillLevelRestrictions));
                                } else {
                                    LOGGER.warn("03 Restriction {} contains an unrecognized crafting id called {}.", mapKey, craftingIdentifier);
                                }
                            }
                        }
                        // entities
                        if (restrictionJsonObject.has("entities")) {
                            for (JsonElement entityElement : restrictionJsonObject.getAsJsonArray("entities")) {
                                class_2960 entityIdentifier = class_2960.method_60654(entityElement.getAsString());
                                if (class_7923.field_41177.method_10250(entityIdentifier)) {
                                    int entityRawId = class_7923.field_41177.method_10206(class_7923.field_41177.method_63535(entityIdentifier));

                                    if (entityList.contains(entityRawId)) {
                                        continue;
                                    }
                                    if (replace) {
                                        entityList.add(entityRawId);
                                    }
                                    LevelManager.ENTITY_RESTRICTIONS.put(entityRawId, new PlayerRestriction(entityRawId, skillLevelRestrictions));
                                } else {
                                    LOGGER.warn("04 Restriction {} contains an unrecognized entity id called {}.", mapKey, entityIdentifier);
                                }
                            }
                        }
                        // items
                        if (restrictionJsonObject.has("items")) {
                            for (JsonElement itemElement : restrictionJsonObject.getAsJsonArray("items")) {
                                class_2960 itemIdentifier = class_2960.method_60654(itemElement.getAsString());
                                if (class_7923.field_41178.method_10250(itemIdentifier)) {
                                    int itemRawId = class_7923.field_41178.method_10206(class_7923.field_41178.method_63535(itemIdentifier));

                                    if (itemList.contains(itemRawId)) {
                                        continue;
                                    }
                                    if (replace) {
                                        itemList.add(itemRawId);
                                    }
                                    LevelManager.ITEM_RESTRICTIONS.put(itemRawId, new PlayerRestriction(itemRawId, skillLevelRestrictions));
                                } else {
                                    LOGGER.warn(" 05 Restriction {} contains an unrecognized item id called {}.", mapKey, itemIdentifier);
                                }
                            }
                        }
                        // mining
                        if (restrictionJsonObject.has("mining")) {
                            for (JsonElement miningElement : restrictionJsonObject.getAsJsonArray("mining")) {
                                class_2960 miningIdentifier = class_2960.method_60654(miningElement.getAsString());
                                if (class_7923.field_41175.method_10250(miningIdentifier)) {
                                    int miningRawId = class_7923.field_41175.method_10206(class_7923.field_41175.method_63535(miningIdentifier));

                                    if (miningList.contains(miningRawId)) {
                                        continue;
                                    }
                                    if (replace) {
                                        miningList.add(miningRawId);
                                    }
                                    LevelManager.MINING_RESTRICTIONS.put(miningRawId, new PlayerRestriction(miningRawId, skillLevelRestrictions));
                                } else {
                                    LOGGER.warn("06 Restriction {} contains an unrecognized mining id called {}.", mapKey, miningIdentifier);
                                }
                            }
                        }
                        // enchantments
                        if (restrictionJsonObject.has("enchantments")) {
                            JsonObject enchantmentObject = restrictionJsonObject.getAsJsonObject("enchantments");
                            for (String enchantment : enchantmentObject.keySet()) {
                                class_2960 enchantmentIdentifier = class_2960.method_60654(enchantment);
                                int level = enchantmentObject.get(enchantment).getAsInt();
                                if (EnchantmentRegistry.containsId(enchantmentIdentifier, level)) {
                                    int enchantmentRawId = EnchantmentRegistry.getId(enchantmentIdentifier, level);
                                    if (enchantmentList.contains(enchantmentRawId)) {
                                        continue;
                                    }
                                    if (replace) {
                                        enchantmentList.add(enchantmentRawId);
                                    }
                                    LevelManager.ENCHANTMENT_RESTRICTIONS.put(enchantmentRawId, new PlayerRestriction(enchantmentRawId, skillLevelRestrictions));
                                } else {
                                    LOGGER.warn("07 Restriction {} contains an unrecognized enchantment id called {}.", mapKey, enchantmentIdentifier);
                                }
                            }
                        }
                        // Todo: Test
                        if (restrictionJsonObject.has("components")) {
//                            System.out.println(this.itemStringReader.consume(new StringReader("potion[potion_contents={potion:\"fire_resistance\"}]")));
//                            System.out.println(this.itemStringReader.consume(new StringReader("potion[potion_contents={potion:\"fire_resistance\"}]")).components());
//                            System.out.println(this.itemStringReader.consume(new StringReader("potion[potion_contents={potion:\"fire_resistance\"}]")).item().value());
//                            Registries.ENCHANTMENT.

                            JsonObject componentObject = restrictionJsonObject.getAsJsonObject("components");
                            for (String component : componentObject.keySet()) {
                                class_2960 itemIdentifier = class_2960.method_60654(component);
                                if (class_7923.field_41178.method_10250(itemIdentifier)) {
                                    if (class_7923.field_49658.method_10250(class_2960.method_60654(componentObject.get(component).getAsString()))) {
                                        int itemRawId = class_7923.field_41178.method_10206(class_7923.field_41178.method_63535(itemIdentifier));
                                    } else {
                                        LOGGER.warn("08 Restriction {} contains an unrecognized component called {}.", mapKey, componentObject.get(component).getAsString());
                                    }
                                } else {
                                    LOGGER.warn("09 Restriction {} contains an unrecognized item id at component called {}.", mapKey, itemIdentifier);
                                }
                            }
                        }
                    } else {
                        LOGGER.warn("10 Restriction {} does not contain any valid skills.", mapKey);
                    }
                }

            } catch (Exception e) {
                LOGGER.error("11 Error occurred while loading resource {}. {}", id.toString(), e.toString());
            }
        });
    }
}