package com.player_level_skills.init;

import com.player_level_skills.criteria.LevelCriterion;
import com.player_level_skills.criteria.SkillCriterion;
import net.minecraft.class_174;
import net.minecraft.class_274;

public class CriteriaInit {

    public static final class_274 LEVELZ = class_274.method_37270("levelz");

    public static final LevelCriterion LEVEL_UP = class_174.method_767("levelz:level", new LevelCriterion());
    public static final SkillCriterion SKILL_UP = class_174.method_767("levelz:skill",new SkillCriterion());

    public static void init() {
    }

}
