package com.player_level_skills.init;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.io.FileWriter;
import java.io.IOException;

@Environment(EnvType.CLIENT)
public class KeyInit {
    public static class_304 screenKey = new class_304("key.levelz.openskillscreen", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K, class_304.class_11900.field_62556);
    public static class_304 devKey = new class_304("key.levelz.dev", class_3675.class_307.field_1668, GLFW.GLFW_KEY_F8, class_304.class_11900.field_62556);

    public static void init() {
        // Registering
        KeyBindingHelper.registerKeyBinding(screenKey);
        // Callback
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (screenKey.method_1436()) {
                //client.setScreen(new LevelScreen());
                return;
            }
        });
    }

    public static void writeId(String string) {
        try (FileWriter idFile = new FileWriter("idlist.json", true)) {
            idFile.append("\"" + string + "\",");
            idFile.append(System.lineSeparator());
        } catch (IOException ignored) {
        }
    }

}
