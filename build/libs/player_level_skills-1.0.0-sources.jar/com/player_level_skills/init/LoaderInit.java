package com.player_level_skills.init;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_3222;
import net.minecraft.class_3264;
import com.player_level_skills.data.RestrictionLoader;
import com.player_level_skills.data.SkillLoader;
import com.player_level_skills.util.PacketHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LoaderInit {

    public static final Logger LOGGER = LogManager.getLogger("LevelZ");

    public static void init() {
        ResourceManagerHelper.get(class_3264.field_14190).registerReloadListener(new SkillLoader());
        ResourceManagerHelper.get(class_3264.field_14190).registerReloadListener(RestrictionLoader.ID, RestrictionLoader::new);
        ServerLifecycleEvents.END_DATA_PACK_RELOAD.register((server, serverResourceManager, success) -> {
            if (success) {
                for (int i = 0; i < server.method_3760().method_14571().size(); i++) {
                    class_3222 serverPlayerEntity = server.method_3760().method_14571().get(i);
                    PacketHelper.updateSkills(serverPlayerEntity);
                    PacketHelper.updatePlayerSkills(serverPlayerEntity, null);
                }
                LOGGER.info("Finished reload on {}", Thread.currentThread());
            } else {
                LOGGER.error("Failed to reload on {}", Thread.currentThread());
            }
        });
    }

}
