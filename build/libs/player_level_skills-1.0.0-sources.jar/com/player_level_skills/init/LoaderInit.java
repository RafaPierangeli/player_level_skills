package com.player_level_skills.init;

import com.player_level_skills.data.SkillLoader;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_3264;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LoaderInit {

    public static final Logger LOGGER = LogManager.getLogger("LevelZ");

    public static void init() {
        ResourceManagerHelper.get(class_3264.field_14190).registerReloadListener(new SkillLoader());

        LOGGER.info("SkillLoader registered.");
    }
}