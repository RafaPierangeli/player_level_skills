package com.player_level_skills.init;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import com.player_level_skills.Player_level_skills;
import com.player_level_skills.item.RareCandyItem;
import com.player_level_skills.item.StrangePotionItem;

public class ItemInit {

    public static final class_1792 STRANGE_POTION = registerItem("strange_potion", new StrangePotionItem(new class_1792.class_1793().method_7889(16).method_63686(class_5321.method_29179(class_7924.field_41197,class_2960.method_60655("player_level_skills", "strange_potion")))));

    public static final class_1792 RARE_CANDY = registerItem("rare_candy", new StrangePotionItem(new class_1792.class_1793().method_7889(16).method_63686(class_5321.method_29179(class_7924.field_41197,class_2960.method_60655("player_level_skills", "rare_candy")))));


    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655("player_level_skills", name), item);
    }

    public static void registerModItems() {

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41061).register(entries -> {
            // Adiciona os itens utilitários normais
            entries.method_45421(STRANGE_POTION);

        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            // Adiciona os itens utilitários normais
            entries.method_45421(RARE_CANDY);

        });
    }

    public static void init() {
//        FabricBrewingRecipeRegistryBuilder.BUILD.register((builder) -> {
//            builder.registerItemRecipe(Items.DRAGON_BREATH, Items.NETHER_STAR, STRANGE_POTION);
//        });
    }
}
