package com.player_level_skills.init;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import com.player_level_skills.Player_level_skills;
import com.player_level_skills.entity.LevelExperienceOrbEntity;

public class EntityInit {

    public static final boolean isRedstoneBitsLoaded = FabricLoader.getInstance().isModLoaded("redstonebits");

    public static final class_1299<LevelExperienceOrbEntity> LEVEL_EXPERIENCE_ORB = class_1299.class_1300.<LevelExperienceOrbEntity>method_5903(LevelExperienceOrbEntity::new, class_1311.field_17715)
            .method_17687(0.5F, 0.5F).method_5905(class_5321.method_29179(class_7924.field_41266, class_2960.method_60655("player_level_skills", "level_experience_orb")));

    public static void init() {
        class_2378.method_10230(class_7923.field_41177, Player_level_skills.identifierOf("level_experience_orb"), LEVEL_EXPERIENCE_ORB);
    }

}
