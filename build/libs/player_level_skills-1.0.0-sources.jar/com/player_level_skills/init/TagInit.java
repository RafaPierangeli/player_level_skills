package com.player_level_skills.init;

import com.player_level_skills.Player_level_skills;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class TagInit {

    public static final class_6862<class_1792> RESTRICTED_FURNACE_EXPERIENCE_ITEMS = class_6862.method_40092(class_7924.field_41197, Player_level_skills.identifierOf("restricted_furnace_experience_items"));
    public static final class_6862<class_2248> RESTRICTED_ORE_EXPERIENCE_BLOCKS = class_6862.method_40092(class_7924.field_41254, Player_level_skills.identifierOf("restricted_ore_experience_blocks"));

    public static void init() {
    }
}
