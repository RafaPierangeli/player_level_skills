package com.player_level_skills.init;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2960;
import com.player_level_skills.Player_level_skills;
import com.player_level_skills.entity.render.LevelExperienceOrbEntityRenderer;

@Environment(EnvType.CLIENT)
public class RenderInit {

    public static final class_2960 SKILL_TAB_ICON = Player_level_skills.identifierOf("textures/gui/sprites/skill_tab_icon.png");
    public static final class_2960 BAG_TAB_ICON = Player_level_skills.identifierOf("textures/gui/sprites/bag_tab_icon.png");

    public static final class_2960 MINEABLE_INFO = Player_level_skills.identifierOf("mineable_info");
    public static final class_2960 MINEABLE_LEVEL_INFO = Player_level_skills.identifierOf("mineable_level_info");

    public static void init() {
        EntityRendererRegistry.register(EntityInit.LEVEL_EXPERIENCE_ORB, LevelExperienceOrbEntityRenderer::new);

       // TabRegistry.registerInventoryTab(new VanillaInventoryTab(Text.translatable("container.crafting"), BAG_TAB_ICON, 0, InventoryScreen.class));
        //TabRegistry.registerInventoryTab(new LevelzTab(Text.translatable("screen.levelz.skill_screen"), SKILL_TAB_ICON, 1, LevelScreen.class, SkillInfoScreen.class, SkillRestrictionScreen.class));

        //HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
        //    TooltipUtil.renderTooltip(MinecraftClient.getInstance(), drawContext);
        //});

        //ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
        //    TooltipUtil.renderItemTooltip(MinecraftClient.getInstance(), stack, lines);
        //});
    }
}
