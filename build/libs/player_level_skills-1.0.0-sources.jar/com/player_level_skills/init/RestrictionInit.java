package com.player_level_skills.init;

import com.player_level_skills.data.VRestrictionLoader;
import com.player_level_skills.util.PacketHelper;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_3222;
import net.minecraft.class_3264;
import net.minecraft.class_7225;
import net.minecraft.server.MinecraftServer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class RestrictionInit {

    private static boolean firstReloadSkipped = false;

    public static final Logger LOGGER = LogManager.getLogger("LevelZ");


    public static void init() {
        ResourceManagerHelper.get(class_3264.field_14190).registerReloadListener(VRestrictionLoader.ID, VRestrictionLoader::new);

        ServerLifecycleEvents.END_DATA_PACK_RELOAD.register((server, serverResourceManager, success) -> {
            if (!success) {
                LOGGER.error("Failed to reload on {}", Thread.currentThread());
                return;
            }

            if (!firstReloadSkipped) {
                firstReloadSkipped = true;
                LOGGER.info("Skipping first restriction reload on {}", Thread.currentThread());
                return;
            }

            class_7225.class_7874 wrapperLookup = server.method_30611();
            VRestrictionLoader restrictionLoader = new VRestrictionLoader(wrapperLookup);
            restrictionLoader.method_14491(serverResourceManager);

            for (class_3222 serverPlayerEntity : server.method_3760().method_14571()) {
                PacketHelper.updateSkills(serverPlayerEntity);
                PacketHelper.updatePlayerSkills(serverPlayerEntity, null);
            }

            LOGGER.info("Finished restriction reload on {}", Thread.currentThread());
        });

        LOGGER.info("RestrictionInit registered.");
    }
}