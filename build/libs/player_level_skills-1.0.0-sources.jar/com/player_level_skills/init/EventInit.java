package com.player_level_skills.init;

import com.player_level_skills.config.ConfigInit;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2703;
import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.level.PlayerSkill;
import com.player_level_skills.level.Skill;
import com.player_level_skills.mixin.EntityAccessor;
import com.player_level_skills.util.LevelHelper;
import com.player_level_skills.util.PacketHelper;
import java.util.Map;
import java.util.Objects;

public class EventInit {

    public static void init() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            for (Skill skill : LevelManager.SKILLS.values()) {
                LevelHelper.updateSkill(handler.method_32311(), skill);
            }
            PacketHelper.syncEnchantments(handler.method_32311());
            PacketHelper.updateSkills(handler.method_32311());
            PacketHelper.updatePlayerSkills(handler.method_32311(), null);
            PacketHelper.updateRestrictions(handler.method_32311());
        });

        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
            PacketHelper.updatePlayerSkills(player, null);
            PacketHelper.updateLevels(player);
        });

        ServerPlayerEvents.COPY_FROM.register((oldPlayer, newPlayer, alive) -> {
            if (alive) {
                PacketHelper.updatePlayerSkills(newPlayer, oldPlayer);
                PacketHelper.updateLevels(newPlayer);
            }
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            LevelManager newLevelManager = ((LevelManagerAccess) newPlayer).getLevelManager();

            if (ConfigInit.CONFIG.resetCurrentXp) {
                newLevelManager.setLevelProgress(0);
                newLevelManager.setTotalLevelExperience(0);
            }

            if (ConfigInit.CONFIG.levelRetainPercentage < 100) {
                LevelManager oldLevelManager = ((LevelManagerAccess) oldPlayer).getLevelManager();
                float levelRetainPercentageFloat = ConfigInit.CONFIG.levelRetainPercentage / 100;
                int retainedLevel = (int) (oldLevelManager.getOverallLevel() * levelRetainPercentageFloat);

                int pointsToDistribute = retainedLevel * ConfigInit.CONFIG.pointsPerLevel + ConfigInit.CONFIG.startPoints;

                if (oldLevelManager.getSkillPoints() > 0) {
                    int retainingSkillPoints = (int) (oldLevelManager.getSkillPoints() * levelRetainPercentageFloat);
                    newLevelManager.setSkillPoints(retainingSkillPoints);
                    pointsToDistribute -= retainingSkillPoints;
                }
                for (Map.Entry<Integer, PlayerSkill> entry : oldLevelManager.getPlayerSkills().entrySet()) {
                    int retainingLevel = (int) (entry.getValue().getLevel() * levelRetainPercentageFloat);
                    newLevelManager.setSkillLevel(entry.getKey(), retainingLevel);
                    pointsToDistribute -= retainingLevel;
                    if (pointsToDistribute < 0) {
                        break;
                    }
                }
                if (pointsToDistribute > 0) {
                    for (Map.Entry<Integer, PlayerSkill> entry : oldLevelManager.getPlayerSkills().entrySet()) {
                        if (entry.getValue().getLevel() < newLevelManager.getSkillLevel(entry.getKey())) {
                            int levelDifference = newLevelManager.getSkillLevel(entry.getKey()) - entry.getValue().getLevel();
                            if (levelDifference < pointsToDistribute) {
                                newLevelManager.setSkillLevel(entry.getKey(), newLevelManager.getSkillLevel(entry.getKey() + levelDifference));
                                pointsToDistribute -= levelDifference;
                            } else {
                                newLevelManager.setSkillLevel(entry.getKey(), newLevelManager.getSkillLevel(entry.getKey() + pointsToDistribute));
                                pointsToDistribute = 0;
                                break;
                            }
                        }
                    }
                    if (pointsToDistribute > 0) {
                        newLevelManager.setSkillPoints(newLevelManager.getSkillPoints() + pointsToDistribute);
                    }
                }

                PacketHelper.updatePlayerSkills(newPlayer, null);

                newLevelManager.setOverallLevel(retainedLevel);
                PacketHelper.updateLevels(newPlayer);
                newPlayer.method_51469().method_8503().method_3760().method_14581(new class_2703(class_2703.class_5893.field_29137, newPlayer));
            } else {
                PacketHelper.updatePlayerSkills(newPlayer, oldPlayer);

                PacketHelper.updateLevels(newPlayer);
                for (Skill skill : LevelManager.SKILLS.values()) {
                    LevelHelper.updateSkill(newPlayer, skill);
                }
            }
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (!player.method_68878() && !player.method_7325()) {
                LevelManager levelManager = ((LevelManagerAccess) player).getLevelManager();
                if (!levelManager.hasRequiredItemLevel(player.method_5998(hand).method_7909())) {
                    // player.sendMessage(Text.translatable("item.levelz." + customList.get(customList.indexOf(string) + 1) +
                    // ".tooltip", customList.get(customList.indexOf(string) + 2)).formatted(Formatting.RED), true);
                    player.method_7353(class_2561.method_43471("restriction.levelz.locked.tooltip").method_27692(class_124.field_1061), true);
                    return class_1269.field_5814;
                }
            }
            return class_1269.field_5811;
        });

        UseBlockCallback.EVENT.register((player, world, hand, result) -> {
            if (!player.method_68878() && !player.method_7325()) {
                class_2338 blockPos = result.method_17777();
                if (world.method_8505(player, blockPos)) {
                    LevelManager levelManager = ((LevelManagerAccess) player).getLevelManager();
                    if (!levelManager.hasRequiredBlockLevel(world.method_8320(blockPos).method_26204())) {
                        player.method_7353(class_2561.method_43471("restriction.levelz.locked.tooltip").method_27692(class_124.field_1061), true);
                        return class_1269.field_5814;
                    }
                }
            }
            return class_1269.field_5811;
        });

        UseEntityCallback.EVENT.register((player, world, hand, entity, entityHitResult) -> {
            if (!player.method_68878() && !player.method_7325()) {
                if (!entity.method_42148() || !((EntityAccessor) entity).callCanAddPassenger(player)) {
                    LevelManager levelManager = ((LevelManagerAccess) player).getLevelManager();
                    if (!levelManager.hasRequiredEntityLevel(entity.method_5864())) {
                        player.method_7353(class_2561.method_43471("restriction.levelz.locked.tooltip").method_27692(class_124.field_1061), true);
                        return class_1269.field_5814;
                    }
                }
            }
            return class_1269.field_5811;
        });
    }

}
