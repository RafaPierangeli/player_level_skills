package com.player_level_skills.registry;

import net.minecraft.class_1887;
import net.minecraft.class_6880;

public class EnchantmentZ {

    private final class_6880<class_1887> entry;
    private final int level;

    public EnchantmentZ(class_6880<class_1887> entry, int level) {
        this.entry = entry;
        this.level = level;
    }

    public class_6880<class_1887> getEntry() {
        return entry;
    }

    public int getLevel() {
        return level;
    }
}
