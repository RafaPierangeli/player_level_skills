package com.player_level_skills.registry;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1887;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7924;

public class EnchantmentRegistry {

    public static final Map<Integer, EnchantmentZ> ENCHANTMENTS = new HashMap<>();
    public static final Map<String, Integer> INDEX_ENCHANTMENTS = new HashMap<>();

    public static boolean containsId(class_6880<class_1887> enchantment, int level) {
        return containsId(enchantment.toString(), level);
    }

    public static boolean containsId(class_2960 identifier, int level) {
        return containsId(identifier.toString(), level);
    }

    public static boolean containsId(String enchantment, int level) {
        return INDEX_ENCHANTMENTS.containsKey(enchantment + level);
    }

    public static EnchantmentZ getEnchantmentZ(int key) {
        return ENCHANTMENTS.get(key);
    }

    public static int getId(class_6880<class_1887> enchantment, int level) {
        return getId(enchantment.method_55840(), level);
    }

    public static int getId(class_2960 identifier, int level) {
        return getId(identifier.toString(), level);
    }

    public static int getId(String enchantment, int level) {
        return getId(enchantment + level);
    }

    private static int getId(String enchantment) {
        if (INDEX_ENCHANTMENTS.containsKey(enchantment)) {
            return INDEX_ENCHANTMENTS.get(enchantment);
        }
        return -1;
    }

    public static void updateEnchantments(class_7225.class_7874 wrapperLookup) {
        ENCHANTMENTS.clear();
        INDEX_ENCHANTMENTS.clear();
        wrapperLookup.method_46759(class_7924.field_41265).ifPresent(enchantmentWrapper -> {
            // streamEntries() é a forma recomendada na 1.21.11 para iterar registros dinâmicos
            enchantmentWrapper.method_42017().forEach(enchantmentEntry -> {
                // Pegamos o ID único do encantamento (ex: minecraft:sharpness)
                String id = enchantmentEntry.method_40237().method_29177().toString();
                // Acessamos os dados do encantamento através do .value()
                int maxLevel = enchantmentEntry.comp_349().method_8183();

                for (int i = 1; i <= maxLevel; i++) {
                    int nextIndex = ENCHANTMENTS.size();
                    INDEX_ENCHANTMENTS.put(id + i, nextIndex);
                    // Importante: Passar o enchantmentEntry (Reference) para o seu objeto customizado
                    ENCHANTMENTS.put(nextIndex, new EnchantmentZ(enchantmentEntry, i));
                }
            });
        });
    }


}


