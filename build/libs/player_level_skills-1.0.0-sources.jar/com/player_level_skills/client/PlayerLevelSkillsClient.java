package com.player_level_skills.client;

import com.player_level_skills.init.KeyInit;
import com.player_level_skills.init.RenderInit;
import com.player_level_skills.network.LevelClientPacket;
import com.player_level_skills.screen.PlayerLevelSkillsScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class PlayerLevelSkillsClient implements ClientModInitializer {

    public static class_304 OPEN_SCREEN_KEY;

    @Override
    public void onInitializeClient() {

        KeyInit.init();
        LevelClientPacket.init();
        RenderInit.init();




        OPEN_SCREEN_KEY = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.player_level_skills.open_screen",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                class_304.class_11900.field_62556
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (OPEN_SCREEN_KEY.method_1436()) {
                if (client.field_1724 != null) {
                    client.method_1507(new PlayerLevelSkillsScreen());
                }
            }
        });
    }
}
