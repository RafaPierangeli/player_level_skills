package com.player_level_skills.item;

import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.access.ServerPlayerSyncAccess;
import com.player_level_skills.level.LevelManager;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

// Texture made by Pois1x
public class RareCandyItem extends class_1792 {

    public RareCandyItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        if (!world.method_8608()) {
            if (!user.method_68878()) {
                stack.method_7934(1);
            }
            LevelManager levelManager = ((LevelManagerAccess) user).getLevelManager();
            ((ServerPlayerSyncAccess) user)
                    .addLevelExperience(levelManager.getNextLevelExperience() - ((int) (levelManager.getLevelProgress() * levelManager.getNextLevelExperience())));
        }
        return class_1269.field_5812;
    }

}
