package com.player_level_skills.item;

import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.config.ConfigInit;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.util.LevelHelper;
import com.player_level_skills.util.PacketHelper;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_5328;
import net.minecraft.class_5712;
import net.minecraft.item.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StrangePotionItem extends class_1792 {

    public StrangePotionItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (!world.method_8608() && user instanceof class_3222 playerEntity) {
            class_174.field_1198.method_8821(playerEntity, stack);

            LevelManager levelManager = ((LevelManagerAccess) playerEntity).getLevelManager();
            List<Integer> list = new ArrayList<>(levelManager.getPlayerSkills().keySet());
            Collections.shuffle(list);

            for (int skillId : list) {
                if (levelManager.resetSkill(skillId) && !ConfigInit.CONFIG.opStrangePotion) {
                    break;
                }
            }
            PacketHelper.updatePlayerSkills(playerEntity, null);

            if (!playerEntity.method_68878()) {
                stack.method_7934(1);
                if (stack.method_7960()) {
                    return new class_1799(class_1802.field_8469);
                }
                playerEntity.method_31548().method_7394(new class_1799(class_1802.field_8469));
            }

            user.method_32876(class_5712.field_28734);
        }
        return stack;
    }

    @Override
    public int method_7881(class_1799 stack, class_1309 user) {
        return 32;
    }

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return class_1839.field_8946;
    }

    @Override
    public class_1269 method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        return class_5328.method_29282(world, user, hand);
    }

}
