package com.player_level_skills.criteria;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.player_level_skills.access.LevelManagerAccess;
import com.player_level_skills.level.LevelManager;
import com.player_level_skills.level.Skill;
import java.util.Optional;
import net.minecraft.class_2048;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

public class SkillCriterion extends class_4558<SkillCriterion.Conditions> {

    @Override
    public Codec<SkillCriterion.Conditions> method_54937() {
        return SkillCriterion.Conditions.CODEC;
    }

    public void trigger(class_3222 player, String skillName, int skillLevel) {
        this.method_22510(player, conditions -> conditions.matches(player, skillName, skillLevel));
    }

    public record Conditions(Optional<class_5258> player, String skillName, int skillLevel) implements class_4558.class_8788 {

        public static final Codec<SkillCriterion.Conditions> CODEC = RecordCodecBuilder
                .create(instance -> instance
                        .group(class_2048.field_47250.optionalFieldOf("player").forGetter(SkillCriterion.Conditions::comp_2029),
                                Codec.STRING.fieldOf("skill_name").forGetter(SkillCriterion.Conditions::skillName), Codec.INT.fieldOf("skill_level").forGetter(SkillCriterion.Conditions::skillLevel))
                        .apply(instance, SkillCriterion.Conditions::new));

        public boolean matches(class_3222 player, String skillName, int skillLevel) {
            if (!skillName.equals(this.skillName)) {
                return false;
            }
            return skillLevel == this.skillLevel;
        }
    }

}