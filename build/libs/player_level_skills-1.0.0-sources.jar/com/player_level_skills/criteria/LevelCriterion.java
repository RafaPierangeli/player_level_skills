package com.player_level_skills.criteria;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.player_level_skills.access.LevelManagerAccess;
import java.util.Optional;
import net.minecraft.class_2048;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;

public class LevelCriterion extends class_4558<LevelCriterion.Conditions> {

    @Override
    public Codec<Conditions> method_54937() {
        return Conditions.CODEC;
    }

    public void trigger(class_3222 player) {
        this.method_22510(player, conditions -> conditions.matches(player));
    }

    public record Conditions(Optional<class_5258> player, int level) implements class_4558.class_8788 {

        public static final Codec<Conditions> CODEC = RecordCodecBuilder
                .create(instance -> instance
                        .group(class_2048.field_47250.optionalFieldOf("player").forGetter(Conditions::comp_2029),
                                Codec.INT.fieldOf("level").forGetter(Conditions::level))
                        .apply(instance, Conditions::new));

        public boolean matches(class_3222 player) {
            return ((LevelManagerAccess) player).getLevelManager().getOverallLevel() == this.level;
        }

    }

}
