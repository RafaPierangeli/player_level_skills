package com.player_level_skills.entity.render;

import com.player_level_skills.entity.LevelExperienceOrbEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_897;

@Environment(EnvType.CLIENT)
public class LevelExperienceOrbEntityRenderer extends class_897<LevelExperienceOrbEntity, LevelExperienceOrbEntityRenderer.OrbRenderState> {
    private static final class_2960 TEXTURE = class_2960.method_60656("textures/entity/experience_orb.png");

    public LevelExperienceOrbEntityRenderer(class_5617.class_5618 context) {
        super(context);
        this.field_4673 = 0.15F;
        this.field_4672 = 0.75F;
    }

    @Override
    public OrbRenderState method_55269() {
        return new OrbRenderState();
    }

    @Override
    public void updateRenderState(LevelExperienceOrbEntity orb, OrbRenderState state, float tickDelta) {
        super.method_62354(orb, state, tickDelta);
        state.age = orb.field_6012;
        state.orbSize = orb.getOrbSize();
    }

    @Override
    protected int getBlockLight(LevelExperienceOrbEntity orb, class_2338 pos) {
        return class_3532.method_15340(super.method_24087(orb, pos) + 7, 0, 15);
    }

    @Override
    public void render(OrbRenderState state, class_4587 matrixStack, class_11659 queue, class_12075 cameraState) {
        matrixStack.method_22903();

        int j = state.orbSize * 100;
        float h = (float)(j % 4 * 16) / 64.0F;
        float k = (float)(j % 4 * 16 + 16) / 64.0F;
        float l = (float)(j / 4 * 16) / 64.0F;
        float m = (float)(j / 4 * 16 + 16) / 64.0F;

        float r = (float)state.age / 2.0F;
        int red = 30;
        int green = Math.max(190, (int)((class_3532.method_15374(r + (float)(Math.PI * 2.0 / 3.0)) + 1.0F) * 0.7F * 255.0F));
        int blue = Math.max(240, (int)((class_3532.method_15374(r + 0.0F) + 1.0F) * 0.85F * 255.0F));
        int alpha = 255;

        matrixStack.method_46416(0.0F, 0.1F, 0.0F);
        matrixStack.method_22907(this.field_4676.field_4686.method_23767());
        matrixStack.method_22905(0.3F, 0.3F, 0.3F);

        class_4587.class_4665 entry = matrixStack.method_23760();

        queue.method_73483(matrixStack, class_12249.method_75998(TEXTURE), new class_11659.class_11660() {
            @Override
            public void render(class_4587.class_4665 matricesEntry, class_4588 vertexConsumer) {
                vertex(vertexConsumer, matricesEntry, -0.5F, -0.25F, red, green, blue, alpha, h, m);
                vertex(vertexConsumer, matricesEntry, 0.5F, -0.25F, red, green, blue, alpha, k, m);
                vertex(vertexConsumer, matricesEntry, 0.5F, 0.75F, red, green, blue, alpha, k, l);
                vertex(vertexConsumer, matricesEntry, -0.5F, 0.75F, red, green, blue, alpha, h, l);
            }
        });

        matrixStack.method_22909();
    }

    private static void vertex(class_4588 vertexConsumer, class_4587.class_4665 entry,
                               float x, float y, int red, int green, int blue, int alpha,
                               float u, float v) {
        vertexConsumer.method_56824(entry, x, y, 0.0F)
                .method_1336(red, green, blue, alpha)
                .method_22913(u, v)
                .method_22922(class_4608.field_21444)
                .method_60803(15728880)
                .method_60831(entry, 0.0F, 1.0F, 0.0F);
    }

    public static class OrbRenderState extends class_10017 {
        public int orbSize;
        public int age;
    }
}


//@Environment(EnvType.CLIENT)
//public class LevelExperienceOrbEntityRenderer extends EntityRenderer<LevelExperienceOrbEntity, EntityRenderState> {
//    private static final Identifier TEXTURE = Identifier.ofVanilla("textures/entity/experience_orb.png");
//    private static final RenderLayer LAYER = RenderLayers.entityTranslucentEmissive(TEXTURE);
//
//    public LevelExperienceOrbEntityRenderer(EntityRendererFactory.Context context) {
//        super(context);
//        this.shadowRadius = 0.15f;
//        this.shadowOpacity = 0.75f;
//    }
//
//    @Override
//    protected int getBlockLight(LevelExperienceOrbEntity experienceOrbEntity, BlockPos blockPos) {
//        return MathHelper.clamp(super.getBlockLight(experienceOrbEntity, blockPos) + 7, 0, 15);
//    }
//
//    @Override
//    public EntityRenderState createRenderState() {
//        return null;
//    }
//
//    //@Override
//    public void render(LevelExperienceOrbEntity experienceOrbEntity, float f, float g, MatrixStack matrixStack, VertexConsumerProvider vertexConsumerProvider, int i) {
//        matrixStack.push();
//        int j = experienceOrbEntity.getOrbSize()*100;
//        float h = (float)(j % 4 * 16) / 64.0F;
//        float k = (float)(j % 4 * 16 + 16) / 64.0F;
//        float l = (float)(j / 4 * 16) / 64.0F;
//        float m = (float)(j / 4 * 16 + 16) / 64.0F;
//        float r = ((float)experienceOrbEntity.age + g) / 2.0F;
//        int s = Math.max(80,(int)((MathHelper.sin(r + 0.0F) + 1.0F) * 0.5F * 255.0F));
//        int u = Math.max(100,(int)((MathHelper.sin(r + (float) (Math.PI * 4.0 / 3.0)) + 1.0F) * 0.1F * 255.0F));
//        matrixStack.translate(0.0F, 0.1F, 0.0F);
//        matrixStack.multiply(this.dispatcher.camera.getRotation());
//        matrixStack.scale(0.3F, 0.3F, 0.3F);
//        VertexConsumer vertexConsumer = vertexConsumerProvider.getBuffer(LAYER);
//        MatrixStack.Entry entry = matrixStack.peek();
//        vertex(vertexConsumer, entry, -0.5F, -0.25F, u,s, 255, h, m, i);
//        vertex(vertexConsumer, entry, 0.5F, -0.25F, u,s, 255, k, m, i);
//        vertex(vertexConsumer, entry, 0.5F, 0.75F, u,s, 255, k, l, i);
//        vertex(vertexConsumer, entry, -0.5F, 0.75F, u,s, 255, h, l, i);
//        matrixStack.pop();
//        render(experienceOrbEntity, f, g, matrixStack, vertexConsumerProvider, i);
//    }
//
//    private static void vertex(VertexConsumer vertexConsumer, MatrixStack.Entry matrix, float x, float y, int red, int green, int blue, float u, float v, int light) {
//        vertexConsumer.vertex(matrix, x, y, 0.0F).color(red, green, blue, 128).texture(u, v).overlay(OverlayTexture.DEFAULT_UV).light(light).normal(matrix, 0.0F, 1.0F, 0.0F);
//    }
//
//    //@Override
//    public Identifier getTexture(LevelExperienceOrbEntity experienceOrbEntity) {
//        return TEXTURE;
//    }
//}
