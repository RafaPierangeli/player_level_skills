package com.player_level_skills.entity.render;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import com.player_level_skills.entity.LevelExperienceOrbEntity;
import net.minecraft.class_10017;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_897;
import net.minecraft.client.render.*;

import static net.minecraft.class_4525.method_29408;

@Environment(EnvType.CLIENT)
public class LevelExperienceOrbEntityRenderer extends class_897<LevelExperienceOrbEntity, class_10017> {
    private static final class_2960 TEXTURE = class_2960.method_60656("textures/entity/experience_orb.png");
    private static final class_1921 LAYER = class_12249.method_76002(TEXTURE);

    public LevelExperienceOrbEntityRenderer(class_5617.class_5618 context) {
        super(context);
        this.field_4673 = 0.15f;
        this.field_4672 = 0.75f;
    }

    @Override
    protected int getBlockLight(LevelExperienceOrbEntity experienceOrbEntity, class_2338 blockPos) {
        return class_3532.method_15340(super.method_24087(experienceOrbEntity, blockPos) + 7, 0, 15);
    }

    @Override
    public class_10017 method_55269() {
        return null;
    }

    //@Override
    public void render(LevelExperienceOrbEntity experienceOrbEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i) {
        matrixStack.method_22903();
        int j = experienceOrbEntity.getOrbSize()*100;
        float h = (float)(j % 4 * 16) / 64.0F;
        float k = (float)(j % 4 * 16 + 16) / 64.0F;
        float l = (float)(j / 4 * 16) / 64.0F;
        float m = (float)(j / 4 * 16 + 16) / 64.0F;
        float r = ((float)experienceOrbEntity.field_6012 + g) / 2.0F;
        int s = Math.max(80,(int)((class_3532.method_15374(r + 0.0F) + 1.0F) * 0.5F * 255.0F));
        int u = Math.max(100,(int)((class_3532.method_15374(r + (float) (Math.PI * 4.0 / 3.0)) + 1.0F) * 0.1F * 255.0F));
        matrixStack.method_46416(0.0F, 0.1F, 0.0F);
        matrixStack.method_22907(this.field_4676.field_4686.method_23767());
        matrixStack.method_22905(0.3F, 0.3F, 0.3F);
        class_4588 vertexConsumer = vertexConsumerProvider.method_73477(LAYER);
        class_4587.class_4665 entry = matrixStack.method_23760();
        vertex(vertexConsumer, entry, -0.5F, -0.25F, u,s, 255, h, m, i);
        vertex(vertexConsumer, entry, 0.5F, -0.25F, u,s, 255, k, m, i);
        vertex(vertexConsumer, entry, 0.5F, 0.75F, u,s, 255, k, l, i);
        vertex(vertexConsumer, entry, -0.5F, 0.75F, u,s, 255, h, l, i);
        matrixStack.method_22909();
        render(experienceOrbEntity, f, g, matrixStack, vertexConsumerProvider, i);
    }

    private static void vertex(class_4588 vertexConsumer, class_4587.class_4665 matrix, float x, float y, int red, int green, int blue, float u, float v, int light) {
        vertexConsumer.method_56824(matrix, x, y, 0.0F).method_1336(red, green, blue, 128).method_22913(u, v).method_22922(class_4608.field_21444).method_60803(light).method_60831(matrix, 0.0F, 1.0F, 0.0F);
    }

    //@Override
    public class_2960 getTexture(LevelExperienceOrbEntity experienceOrbEntity) {
        return TEXTURE;
    }
}
